from decimal import Decimal
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.db import transaction
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from rest_framework.decorators import api_view, permission_classes, parser_classes
from rest_framework.parsers import MultiPartParser, FormParser
from django.contrib.auth import get_user_model
from programs.services.carton_calculator import CartonCalculator



from activity_logs.utils import create_log


from .models import (

    CartonProgram,
    ActivityProgramStatus,
    CartonProgramSubProgram,
    SampleProgram,
    CartonProgramAttachment,
    BedsheetProgramDetails,
    TerryTowelProgramDetails,
    BathRobeProgramDetails,
    GussetProgram,
    GussetProgramSpecification,
    GussetSampleProgram
    
)


from programs.services.notification_service import NotificationService
from django.utils import timezone


# ------------------------------------------------------------------
# Small shared validators
# ------------------------------------------------------------------
# These views write directly via .objects.create()/manual attribute
# assignment (no DRF serializers), so model-level choices= is not enough to
# stop bad values reaching the DB - validate explicitly at the API boundary.

def _validate_yes_no(value, field_label):
    """
    Returns (clean_value, error_response). clean_value is None if the input
    itself was None/blank (field is optional). error_response is a DRF
    Response if validation failed, else None.
    """
    if value is None or value == "":
        return None, None

    cleaned = str(value).strip().upper()

    if cleaned not in ("YES", "NO"):
        return None, Response(
            {"error": f"{field_label} must be 'YES' or 'NO'"},
            status=400
        )

    return cleaned, None






from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi




# ------------------------------------------------------------------
# API: Submit Carton Program
# Description:
#   Creates a new Carton Program.
#
#   Supports Multiple Program Types:
#   - TOWEL (default)
#   - BEDSHEET
#   - TERRY_TOWEL
#   - BATH_ROBE
#
#   Creates:
#   - CartonProgram (common fields)
#   - Product Specific Details Model
#   - Sub Programs
#   - Sample Programs
#   - Activity Program Status
#
#   Sends Notifications based on workflow
# ------------------------------------------------------------------

bedsheet_details_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "fabric_tc": openapi.Schema(type=openapi.TYPE_STRING),
        "folding_details": openapi.Schema(type=openapi.TYPE_STRING),
        "required_pcs_per_polybag": openapi.Schema(type=openapi.TYPE_INTEGER),
        "polybag_size": openapi.Schema(type=openapi.TYPE_STRING),
        "product_type": openapi.Schema(type=openapi.TYPE_STRING),
        "special_packing_requirement": openapi.Schema(type=openapi.TYPE_STRING),
        "packing_type": openapi.Schema(type=openapi.TYPE_STRING),
        "product_dimension": openapi.Schema(type=openapi.TYPE_STRING),
        "fold_size": openapi.Schema(type=openapi.TYPE_STRING),
        "blister_packing_required": openapi.Schema(type=openapi.TYPE_BOOLEAN),
        "blister_packing_details": openapi.Schema(type=openapi.TYPE_STRING),
        "bag_type": openapi.Schema(type=openapi.TYPE_STRING),
        "special_box_required": openapi.Schema(type=openapi.TYPE_STRING),
        "required_sets_per_carton": openapi.Schema(type=openapi.TYPE_INTEGER),
        "polyfold_condition": openapi.Schema(type=openapi.TYPE_STRING),
        "filled_product_gsm": openapi.Schema(type=openapi.TYPE_NUMBER),
    }
)

terry_details_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "towel_sizes": openapi.Schema(type=openapi.TYPE_STRING),
        "required_pcs_carton_size": openapi.Schema(type=openapi.TYPE_STRING),
        "required_polybags_carton_size": openapi.Schema(type=openapi.TYPE_STRING),
        "towel_dimensions": openapi.Schema(type=openapi.TYPE_STRING),
        "towel_weight_per_piece": openapi.Schema(type=openapi.TYPE_NUMBER),
        "folding_details": openapi.Schema(type=openapi.TYPE_STRING),
        "required_pcs_per_polybag": openapi.Schema(type=openapi.TYPE_INTEGER),
        "special_carton_details": openapi.Schema(type=openapi.TYPE_STRING),
    }
)


bathrobe_details_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "original_bath_robe": openapi.Schema(type=openapi.TYPE_STRING),
        "bath_robe_sizes": openapi.Schema(type=openapi.TYPE_STRING),
        "bath_robe_dimensions": openapi.Schema(type=openapi.TYPE_STRING),
        "bath_robe_weight": openapi.Schema(type=openapi.TYPE_NUMBER),
        "folding_details": openapi.Schema(type=openapi.TYPE_STRING),
        "required_pcs_per_polybag": openapi.Schema(type=openapi.TYPE_INTEGER),
        "required_pcs_per_carton": openapi.Schema(type=openapi.TYPE_INTEGER),
        "polybag_type": openapi.Schema(type=openapi.TYPE_STRING),
        "polybag_size_carton": openapi.Schema(type=openapi.TYPE_STRING),
    }
)


carton_program_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={

        # --------------------------------------------------
        # BASIC DETAILS
        # --------------------------------------------------
        "customer_name": openapi.Schema(type=openapi.TYPE_STRING),
        "program_name": openapi.Schema(type=openapi.TYPE_STRING),
        "customer_protocol": openapi.Schema(type=openapi.TYPE_STRING),

        "confirm_new_or_shifted_from_vapi": openapi.Schema(
            type=openapi.TYPE_STRING
        ),

        "original_towel": openapi.Schema(type=openapi.TYPE_STRING),

        # --------------------------------------------------
        # POLYBAG
        # --------------------------------------------------
        "polybag_manual_or_automatic": openapi.Schema(
            type=openapi.TYPE_STRING
        ),
        "polybag_type": openapi.Schema(type=openapi.TYPE_STRING),

        # --------------------------------------------------
        # BOOLEAN FLAGS
        # --------------------------------------------------
        "pallet_or_slipsheet_requirement": openapi.Schema(
            type=openapi.TYPE_BOOLEAN
        ),
        "special_carton_required": openapi.Schema(
            type=openapi.TYPE_BOOLEAN
        ),
        "pdq_required": openapi.Schema(
            type=openapi.TYPE_BOOLEAN
        ),
        "cdu_required": openapi.Schema(
            type=openapi.TYPE_BOOLEAN
        ),

        # --------------------------------------------------
        # SAMPLE ARRANGED
        # --------------------------------------------------
        "sample_carton_arranged": openapi.Schema(
            type=openapi.TYPE_BOOLEAN
        ),
        "pdq_arranged": openapi.Schema(type=openapi.TYPE_BOOLEAN),
        "cdu_arranged": openapi.Schema(type=openapi.TYPE_BOOLEAN),

        # --------------------------------------------------
        # PDQ CONFIGURATION
        # --------------------------------------------------
        "shipped_as_single_pdq_or_monster_pdq": openapi.Schema(
            type=openapi.TYPE_STRING
        ),
        "pdq_layers_stacking_details": openapi.Schema(
            type=openapi.TYPE_STRING
        ),
        "common_pdq_same_dimension_for_all_sizes": openapi.Schema(
            type=openapi.TYPE_STRING
        ),

        # --------------------------------------------------
        # PALLET / STORE
        # --------------------------------------------------
        "small_pdq_on_pallet_or_slipsheet": openapi.Schema(
            type=openapi.TYPE_STRING
        ),
        "small_pdq_count_on_pallet_or_slipsheet": openapi.Schema(
            type=openapi.TYPE_STRING
        ),
        "warehouse_store_handling_method": openapi.Schema(
            type=openapi.TYPE_STRING
        ),

        # --------------------------------------------------
        # PACKING
        # --------------------------------------------------
        "towel_folded_and_poly_packed_before_carton": openapi.Schema(
            type=openapi.TYPE_STRING
        ),
        "separator_protector_stiffener_required": openapi.Schema(
            type=openapi.TYPE_STRING
        ),
        "ribbon_packing_required": openapi.Schema(
            type=openapi.TYPE_STRING
        ),
        "belly_band_packing_required": openapi.Schema(
            type=openapi.TYPE_STRING
        ),
    }
)


subprogram_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={

        # --------------------------------------------------
        # BASIC DETAILS
        # --------------------------------------------------
        "program_name": openapi.Schema(type=openapi.TYPE_STRING),
        "style": openapi.Schema(type=openapi.TYPE_STRING),

        # NEW: Size (King/Queen/etc.) + Product Type (Sheet Set/Flat Sheet/etc.)
        "size": openapi.Schema(
            type=openapi.TYPE_STRING,
            enum=["SINGLE", "TWIN", "TWIN XL", "FULL", "QUEEN", "KING", "CALIFORNIA KING", "OTHER"]
        ),
        "product_type": openapi.Schema(
            type=openapi.TYPE_STRING,
            enum=["SHEET_SET", "FLAT_SHEET", "FITTED_SHEET", "PILLOWCASE", "DUVET_COVER", "OTHER"]
        ),

        "width_in": openapi.Schema(type=openapi.TYPE_NUMBER, description="Packed product dimension - open form (inches)"),
        "length_in": openapi.Schema(type=openapi.TYPE_NUMBER, description="Packed product dimension - open form (inches)"),
        "width_cm": openapi.Schema(type=openapi.TYPE_NUMBER, description="Packed product dimension - open form (cm). Auto-derived from width_in if omitted."),
        "length_cm": openapi.Schema(type=openapi.TYPE_NUMBER, description="Packed product dimension - open form (cm). Auto-derived from length_in if omitted."),

        "wt_per_unit": openapi.Schema(type=openapi.TYPE_NUMBER, description="Weight per piece - editable"),
        "weight_uom": openapi.Schema(
            type=openapi.TYPE_STRING,
            enum=["GM", "KG", "LB"],
            description="UOM for wt_per_unit"
        ),
        "gsm": openapi.Schema(type=openapi.TYPE_NUMBER),

        "unit_per_carton": openapi.Schema(type=openapi.TYPE_INTEGER),
        "inner_pack_unit_qty": openapi.Schema(type=openapi.TYPE_STRING),
        "fold": openapi.Schema(type=openapi.TYPE_STRING),

        # --------------------------------------------------
        # TQM CARTON FIELDS
        # --------------------------------------------------
        "carton_length": openapi.Schema(type=openapi.TYPE_NUMBER, description="cm"),
        "carton_width": openapi.Schema(type=openapi.TYPE_NUMBER, description="cm"),
        "carton_height": openapi.Schema(type=openapi.TYPE_NUMBER, description="cm"),

        "ribbon": openapi.Schema(type=openapi.TYPE_STRING, enum=["YES", "NO"]),
        "belly_band": openapi.Schema(type=openapi.TYPE_STRING, enum=["YES", "NO"]),
        "self_fabric_bag": openapi.Schema(type=openapi.TYPE_STRING, enum=["YES", "NO"]),
        "remark": openapi.Schema(type=openapi.TYPE_STRING),

        # --------------------------------------------------
        # PDQ FIELDS
        # --------------------------------------------------
        "pdq_length": openapi.Schema(type=openapi.TYPE_NUMBER),
        "pdq_width": openapi.Schema(type=openapi.TYPE_NUMBER),
        "pdq_height": openapi.Schema(type=openapi.TYPE_NUMBER),

        "net_wt_pdq": openapi.Schema(type=openapi.TYPE_NUMBER),
        "pallet_wt_pdq": openapi.Schema(type=openapi.TYPE_NUMBER),

        # --------------------------------------------------
        # PALLET SIZE
        # --------------------------------------------------
        "pallet_length": openapi.Schema(type=openapi.TYPE_NUMBER),
        "pallet_width": openapi.Schema(type=openapi.TYPE_NUMBER),
        "pallet_height": openapi.Schema(type=openapi.TYPE_NUMBER),
        
        # --------------------------------------------------
        # PACKED PB SIZE
        # --------------------------------------------------
        "packed_pb_length": openapi.Schema(type=openapi.TYPE_NUMBER),
        "packed_pb_width": openapi.Schema(type=openapi.TYPE_NUMBER),
        "packed_pb_height": openapi.Schema(type=openapi.TYPE_NUMBER),

        # --------------------------------------------------
        # WAREHOUSE FIELDS
        # --------------------------------------------------
        "article_no": openapi.Schema(type=openapi.TYPE_STRING),
        "so_item_text": openapi.Schema(type=openapi.TYPE_STRING),
        "possible_ca": openapi.Schema(type=openapi.TYPE_INTEGER),
        "ship_qty": openapi.Schema(type=openapi.TYPE_INTEGER),
        "gross_wt_per_carton": openapi.Schema(type=openapi.TYPE_NUMBER),
        "upc": openapi.Schema(type=openapi.TYPE_STRING),
        "final_destination": openapi.Schema(type=openapi.TYPE_STRING),
    }
)


sample_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "program_name": openapi.Schema(type=openapi.TYPE_STRING),
        "size": openapi.Schema(type=openapi.TYPE_STRING),
        "sample": openapi.Schema(type=openapi.TYPE_STRING),
        "quality": openapi.Schema(type=openapi.TYPE_STRING),
        "lbs_per_dz": openapi.Schema(type=openapi.TYPE_NUMBER),
        "gsm": openapi.Schema(type=openapi.TYPE_NUMBER),
        "shade": openapi.Schema(type=openapi.TYPE_STRING),
        "width_in": openapi.Schema(type=openapi.TYPE_NUMBER),
        "length_in": openapi.Schema(type=openapi.TYPE_NUMBER),
        "width_cm": openapi.Schema(type=openapi.TYPE_NUMBER),
        "length_cm": openapi.Schema(type=openapi.TYPE_NUMBER),
    }
)



submit_carton_program_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["activity_name", "program_name"],
    properties={
        "activity_name": openapi.Schema(type=openapi.TYPE_STRING),
        "program_name": openapi.Schema(type=openapi.TYPE_STRING),

        "program_type": openapi.Schema(
            type=openapi.TYPE_STRING,
            enum=["TOWEL", "BEDSHEET", "TERRY_TOWEL", "BATH_ROBE"]
        ),

        "sent_to_user_id": openapi.Schema(type=openapi.TYPE_INTEGER),

        "btn": openapi.Schema(type=openapi.TYPE_STRING),

        "carton_program": carton_program_schema,

        "subprograms": openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=subprogram_schema
        ),

        "samples": openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=sample_schema
        ),

        "bedsheet_details": bedsheet_details_schema,
        "terry_details": terry_details_schema,
        "bathrobe_details": bathrobe_details_schema,
    }
)


@swagger_auto_schema(
    method="post",
    operation_summary="Submit Carton Program (All Product Types)",
    request_body=submit_carton_program_schema,
)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
@transaction.atomic
def submit_carton_program(request):

    data = request.data

    activity_name = data.get("activity_name")
    program_name = data.get("program_name")
    program_type = data.get("program_type", "TOWEL")
    sent_to_user_id = data.get("sent_to_user_id")
    btn = data.get("btn", "")

    if not activity_name:
        return Response({"error": "activity_name is required"}, status=400)

    if not program_name:
        return Response({"error": "program_name is required"}, status=400)

    carton_program_data = data.get("carton_program", {})
    subprograms = data.get("subprograms", [])
    samples = data.get("samples", [])

    # --------------------------------------------------
    # 1️⃣ CREATE MAIN CARTON PROGRAM
    # --------------------------------------------------

    carton_program = CartonProgram.objects.create(
        program_type=program_type,
        program_name=program_name,
        created_by=request.user,

        remark=carton_program_data.get("remark"),
        customer_name=carton_program_data.get("customer_name"),
        customer_protocol=carton_program_data.get("customer_protocol"),
        confirm_new_or_shifted_from_vapi=carton_program_data.get("confirm_new_or_shifted_from_vapi"),
        original_towel=carton_program_data.get("original_towel"),

        polybag_manual_or_automatic=carton_program_data.get("polybag_manual_or_automatic"),
        polybag_type=carton_program_data.get("polybag_type"),

        pallet_or_slipsheet_requirement=carton_program_data.get("pallet_or_slipsheet_requirement", False),
        special_carton_required=carton_program_data.get("special_carton_required", False),
        pdq_required=carton_program_data.get("pdq_required", False),
        cdu_required=carton_program_data.get("cdu_required", False),

        sample_arranged_for_special_carton=carton_program_data.get("sample_carton_arranged", False),
        sample_arranged_for_special_carton_pdq=carton_program_data.get("pdq_arranged", False),
        sample_arranged_for_special_carton_cdu=carton_program_data.get("cdu_arranged", False),

        shipped_as_single_pdq_or_monster_pdq=carton_program_data.get("shipped_as_single_pdq_or_monster_pdq"),
        pdq_layers_stacking_details=carton_program_data.get("pdq_layers_stacking_details"),
        common_pdq_same_dimension_for_all_sizes=carton_program_data.get("common_pdq_same_dimension_for_all_sizes"),

        small_pdq_on_pallet_or_slipsheet=carton_program_data.get("small_pdq_on_pallet_or_slipsheet"),
        small_pdq_count_on_pallet_or_slipsheet=carton_program_data.get("small_pdq_count_on_pallet_or_slipsheet"),
        warehouse_store_handling_method=carton_program_data.get("warehouse_store_handling_method"),

        towel_folded_and_poly_packed_before_carton=carton_program_data.get("towel_folded_and_poly_packed_before_carton"),
        separator_protector_stiffener_required=carton_program_data.get("separator_protector_stiffener_required"),
        ribbon_packing_required=carton_program_data.get("ribbon_packing_required"),
        belly_band_packing_required=carton_program_data.get("belly_band_packing_required"),
    )

    # --------------------------------------------------
    # 2️⃣ PRODUCT-SPECIFIC DETAILS
    # --------------------------------------------------

    if program_type == "BEDSHEET":
        BedsheetProgramDetails.objects.create(
            carton_program=carton_program,
            **data.get("bedsheet_details", {})
        )

    elif program_type == "TERRY_TOWEL":
        TerryTowelProgramDetails.objects.create(
            carton_program=carton_program,
            **data.get("terry_details", {})
        )

    # elif program_type == "BATH_ROBE":
    #     BathRobeProgramDetails.objects.create(
    #         carton_program=carton_program,
    #         **data.get("bathrobe_details", {})
    #     )

    elif program_type == "BATH_ROBE":

        bathrobe_details = data.get("bathrobe_details", {}).copy()

        # Remove fields that do not exist in BathRobeProgramDetails
        bathrobe_details.pop("remark", None)

        BathRobeProgramDetails.objects.create(
            carton_program=carton_program,
            **bathrobe_details
        )

    # --------------------------------------------------
    # 3️⃣ CREATE ACTIVITY STATUS
    # --------------------------------------------------

    status_value = "Draft" if btn.lower() == "save as draft" else "Pending"

    ActivityProgramStatus.objects.create(
        activity=activity_name,
        program=carton_program,
        status=status_value,
        sent_to_id=sent_to_user_id,
        created_by=request.user
    )

    # --------------------------------------------------
    # 4️⃣ CREATE SUBPROGRAMS (Explicit Mapping - Safe)
    # --------------------------------------------------

    # for sp in subprograms:
    #     CartonProgramSubProgram.objects.create(
    #         carton_program=carton_program,
    #         program_name=sp.get("program_name"),
    #         style=sp.get("style"),
    #         width_in=sp.get("width_in"),
    #         length_in=sp.get("length_in"),
    #         width_cm=sp.get("width_cm"),
    #         length_cm=sp.get("length_cm"),
    #         wt_per_unit=sp.get("wt_per_unit"),
    #         gsm=sp.get("gsm"),
    #         unit_per_carton=sp.get("unit_per_carton"),
    #         inner_pack_unit_qty=sp.get("inner_pack_unit_qty"),
    #         fold=sp.get("fold"),
    #         pcs_per_set=sp.get("pcs_per_set"),
    #         remark=sp.get("remark")
    #     )


    calc = CartonCalculator()

    for sp in subprograms:

        result = calc.compute(sp)

        # -------- Yes/No dropdown validation --------
        ribbon_val, err = _validate_yes_no(sp.get("ribbon"), "ribbon")
        if err:
            return err

        belly_band_val, err = _validate_yes_no(sp.get("belly_band"), "belly_band")
        if err:
            return err

        self_fabric_bag_val, err = _validate_yes_no(sp.get("self_fabric_bag"), "self_fabric_bag")
        if err:
            return err

        # -------- width/length in cm (open-form packed dimension) --------
        width_cm = sp.get("width_cm")
        length_cm = sp.get("length_cm")

        if width_cm is None and sp.get("width_in") is not None:
            width_cm = round(Decimal(str(sp.get("width_in"))) * Decimal("2.54"), 2)

        if length_cm is None and sp.get("length_in") is not None:
            length_cm = round(Decimal(str(sp.get("length_in"))) * Decimal("2.54"), 2)

        CartonProgramSubProgram.objects.create(
            carton_program=carton_program,

            program_name=sp.get("program_name"),
            style=sp.get("style"),

            # NEW: Size (King/Queen/etc.) + Product Type (Sheet Set/Flat Sheet/etc.)
            size=sp.get("size"),
            product_type=sp.get("product_type"),

            width_in=sp.get("width_in"),
            length_in=sp.get("length_in"),

            # Packed product dimension - open form (now actually populated)
            width_cm=width_cm,
            length_cm=length_cm,

            gsm=sp.get("gsm"),
            # Weight is always editable - honors marketing's input if given,
            # otherwise falls back to the calculator's estimate.
            wt_per_unit=result["weight"],
            weight_uom=sp.get("weight_uom", "GM"),

            unit_per_carton=sp.get("unit_per_carton"),
            inner_pack_unit_qty=sp.get("inner_pack_unit_qty"),

            fold=sp.get("fold"),
            pcs_per_set=sp.get("pcs_per_set"),
            remark=sp.get("remark"),

            ribbon=ribbon_val,
            belly_band=belly_band_val,
            self_fabric_bag=self_fabric_bag_val,

            # Packed product dimension - folded form
            folded_length=result["folded_length"],
            folded_width=result["folded_width"],

            # Carton dims - now consistently in cm (see carton_calculator.py fix)
            carton_length=result["carton"]["length"],
            carton_width=result["carton"]["width"],
            carton_height=result["carton"]["height"],
        )

    # --------------------------------------------------
    # 5️⃣ CREATE SAMPLE PROGRAMS
    # --------------------------------------------------

    for sm in samples:
        SampleProgram.objects.create(
            carton_program=carton_program,
            program_name=sm.get("program_name"),
            size=sm.get("size"),
            sample=sm.get("sample"),
            quality=sm.get("quality"),
            lbs_per_dz=sm.get("lbs_per_dz"),
            gsm=sm.get("gsm"),
            shade=sm.get("shade"),
            width_in=sm.get("width_in"),
            length_in=sm.get("length_in"),
            width_cm=sm.get("width_cm"),
            length_cm=sm.get("length_cm"),
        )
        
        
    User = get_user_model()

    notification = NotificationService()

    # Send confirmation to creator (Marketing)
    try:
        notification.send_request_created(carton_program)
    except Exception as e:
        print("Email failed:", str(e))
    
    # If not draft → send to assigned user
    if status_value != "Draft" and sent_to_user_id:
        try:
            assigned_user = User.objects.get(id=sent_to_user_id)
            notification.send_tqm_notification(carton_program)
        except User.DoesNotExist:
            pass


    # --------------------------------------------------
    # 6️⃣ LOGGING
    # --------------------------------------------------

    create_log(
        module_name="Carton Program",
        record_id=carton_program.id,
        action="Created",
        message=f"{program_type} program created",
        user=request.user
    )

    # --------------------------------------------------
    # 7️⃣ NOTIFICATIONS (Your Original Logic Restored)
    # --------------------------------------------------

    User = get_user_model()
    notification = NotificationService()

    # Send confirmation to creator
    try:
        notification.send_request_created(carton_program)
    except Exception as e:
        print("Email failed:", str(e))

    # Send to assigned user if not draft
    if status_value != "Draft" and sent_to_user_id:
        try:
            assigned_user = User.objects.get(id=sent_to_user_id)
            notification.send_tqm_notification(carton_program)
        except User.DoesNotExist:
            pass

    # --------------------------------------------------
    # 8️⃣ FINAL RESPONSE
    # --------------------------------------------------

    return Response(
        {
            "message": "Carton Program Saved Successfully",
            "program_id": carton_program.id,
            "program_type": program_type
        },
        status=201
    )


# ------------------------------------------------------------------
# API: Get Activity Program Status List
# Description:
#   Returns all activity-program status records along with:
#   - Activity name
#   - Program ID
#   - Program Name
#   - Customer Name
#   - Status
#   - Created On (DD-MM-YYYY)
#   - Last Action Date (DD-MM-YYYY)
# ------------------------------------------------------------------


activity_status_response_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "id": openapi.Schema(type=openapi.TYPE_INTEGER),
        "activity": openapi.Schema(type=openapi.TYPE_STRING),
        "program_id": openapi.Schema(type=openapi.TYPE_INTEGER),
        "program_name": openapi.Schema(type=openapi.TYPE_STRING),
        "customer_name": openapi.Schema(type=openapi.TYPE_STRING),
        "status": openapi.Schema(type=openapi.TYPE_STRING),
        "created_date": openapi.Schema(type=openapi.TYPE_STRING),
        "last_action_date": openapi.Schema(type=openapi.TYPE_STRING),
    }
)


@swagger_auto_schema(
    method="get",
    responses={
        200: openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=activity_status_response_schema
        )
    }
)
@api_view(["GET"])
@permission_classes([IsAuthenticated])
def get_activity_program_status_list(request):
    """
    Fetch all activity-program status records
    """

    records = ActivityProgramStatus.objects.select_related(
        "program"
    ).filter(created_by=request.user)

    response_data = []

    for obj in records:
        response_data.append({
            "id": obj.id,
            "activity": obj.activity,

            "program_id": obj.program.id,
            "program_name": obj.program.program_name,
            "customer_name": obj.program.customer_name,

            "status": obj.status,

            # "created_date": obj.created_on.strftime("%d-%m-%Y")
            # if obj.created_on else None,

            # "last_action_date": obj.updated_on.strftime("%d-%m-%Y")
            # if obj.updated_on else None,

            "created_date": obj.created_on.strftime("%d-%m-%Y %H:%M:%S")
            if obj.created_on else None,

            "last_action_date": obj.updated_on.strftime("%d-%m-%Y %H:%M:%S")
            if obj.updated_on else None,

            
            "rejection_reason": obj.rejection_reason

        })

    return Response(response_data)






# ------------------------------------------------------------------
# API: Copy Carton Program
# Description:
#   Creates a duplicate of an existing Carton Program along with:
#   - Sub Programs
#   - Sample Programs
#   - Activity Program Status
#
#   All new records will have NEW IDs.
#   Status of copied Activity Program will always be "Draft".
#
# Input:
#   activity_program_status_id
#
# Output:
#   new_program_id
#   new_activity_status_id
# ------------------------------------------------------------------

copy_carton_program_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["activity_program_status_id"],
    properties={
        "activity_program_status_id": openapi.Schema(
            type=openapi.TYPE_INTEGER,
            description="ActivityProgramStatus ID to copy"
        )
    }
)


copy_carton_program_response_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "message": openapi.Schema(type=openapi.TYPE_STRING),
        "new_program_id": openapi.Schema(type=openapi.TYPE_INTEGER),
        "new_activity_status_id": openapi.Schema(type=openapi.TYPE_INTEGER),
    }
)


@swagger_auto_schema(
    method="post",
    operation_summary="Copy Carton Program",
    operation_description="""
    Creates a duplicate of an existing carton program.

    Copies:
    - Program-level boolean fields
    - Subprograms
    - Sample programs

    Notes:
    - New program is always created in Draft status
    - New IDs are generated
    """,
    request_body=copy_carton_program_schema,
    responses={
        201: copy_carton_program_response_schema,
        400: "Bad Request",
        404: "Not Found"
    }
)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
@transaction.atomic
def copy_carton_program(request):

    aps_id = request.data.get("activity_program_status_id")

    if not aps_id:
        return Response(
            {"error": "activity_program_status_id is required"},
            status=400
        )

    try:
        old_aps = ActivityProgramStatus.objects.select_related(
            "program"
        ).get(id=aps_id)
    except ActivityProgramStatus.DoesNotExist:
        return Response(
            {"error": "Invalid activity_program_status_id"},
            status=404
        )

    old_program = old_aps.program

    # --------------------------------------------------
    # 1. CREATE NEW CARTON PROGRAM (UPDATED FIELDS)
    # --------------------------------------------------

    new_program = CartonProgram.objects.create(

        program_name=f"{old_program.program_name}_COPY",
        customer_name=old_program.customer_name,
        customer_protocol=old_program.customer_protocol,

        confirm_new_or_shifted_from_vapi=old_program.confirm_new_or_shifted_from_vapi,
        original_towel=old_program.original_towel,

        polybag_manual_or_automatic=old_program.polybag_manual_or_automatic,
        polybag_type=old_program.polybag_type,

        # -------- BOOLEAN FIELDS --------
        pallet_or_slipsheet_requirement=old_program.pallet_or_slipsheet_requirement,

        special_carton_required=old_program.special_carton_required,
        pdq_required=old_program.pdq_required,
        cdu_required=old_program.cdu_required,

        sample_arranged_for_special_carton=old_program.sample_arranged_for_special_carton,
        sample_arranged_for_special_carton_pdq=old_program.sample_arranged_for_special_carton_pdq,
        sample_arranged_for_special_carton_cdu=old_program.sample_arranged_for_special_carton_cdu,

        # -------- REMAINING FIELDS --------
        shipped_as_single_pdq_or_monster_pdq=old_program.shipped_as_single_pdq_or_monster_pdq,
        pdq_layers_stacking_details=old_program.pdq_layers_stacking_details,
        common_pdq_same_dimension_for_all_sizes=old_program.common_pdq_same_dimension_for_all_sizes,
        small_pdq_on_pallet_or_slipsheet=old_program.small_pdq_on_pallet_or_slipsheet,
        small_pdq_count_on_pallet_or_slipsheet=old_program.small_pdq_count_on_pallet_or_slipsheet,
        warehouse_store_handling_method=old_program.warehouse_store_handling_method,
        towel_folded_and_poly_packed_before_carton=old_program.towel_folded_and_poly_packed_before_carton,
        separator_protector_stiffener_required=old_program.separator_protector_stiffener_required,
        ribbon_packing_required=old_program.ribbon_packing_required,
        belly_band_packing_required=old_program.belly_band_packing_required,

        created_by=request.user
    )

    # --------------------------------------------------
    # 2. COPY SUBPROGRAMS
    # --------------------------------------------------

    for sp in CartonProgramSubProgram.objects.filter(carton_program=old_program):
        CartonProgramSubProgram.objects.create(
            carton_program=new_program,
            program_name=sp.program_name,
            style=sp.style,

            size=sp.size,
            product_type=sp.product_type,

            width_in=sp.width_in,
            length_in=sp.length_in,
            width_cm=sp.width_cm,
            length_cm=sp.length_cm,

            wt_per_unit=sp.wt_per_unit,
            weight_uom=sp.weight_uom,
            gsm=sp.gsm,
            unit_per_carton=sp.unit_per_carton,
            inner_pack_unit_qty=sp.inner_pack_unit_qty,
            fold=sp.fold,
            pcs_per_set=sp.pcs_per_set,

            folded_length=sp.folded_length,
            folded_width=sp.folded_width,

            carton_length=sp.carton_length,
            carton_width=sp.carton_width,
            carton_height=sp.carton_height,

            ribbon=sp.ribbon,
            belly_band=sp.belly_band,
            self_fabric_bag=sp.self_fabric_bag,
            remark=sp.remark,

            pdq_length=sp.pdq_length,
            pdq_width=sp.pdq_width,
            pdq_height=sp.pdq_height,
            net_wt_pdq=sp.net_wt_pdq,
            pallet_wt_pdq=sp.pallet_wt_pdq,

            pallet_length=sp.pallet_length,
            pallet_width=sp.pallet_width,
            pallet_height=sp.pallet_height,

            packed_pb_length=sp.packed_pb_length,
            packed_pb_width=sp.packed_pb_width,
            packed_pb_height=sp.packed_pb_height,

            # A copy is a new draft - force TQM to recalculate before it can
            # be submitted again, even though the raw numbers are copied.
            is_recalculated=False,
        )

    # --------------------------------------------------
    # 3. COPY SAMPLE PROGRAMS
    # --------------------------------------------------

    for sm in SampleProgram.objects.filter(carton_program=old_program):
        SampleProgram.objects.create(
            carton_program=new_program,
            program_name=sm.program_name,
            size=sm.size,
            sample=sm.sample,
            quality=sm.quality,
            lbs_per_dz=sm.lbs_per_dz,
            gsm=sm.gsm,
            shade=sm.shade,
            width_in=sm.width_in,
            length_in=sm.length_in
        )

    # --------------------------------------------------
    # 4. CREATE NEW ACTIVITY STATUS (DRAFT)
    # --------------------------------------------------

    new_aps = ActivityProgramStatus.objects.create(
        activity=old_aps.activity,
        program=new_program,
        status="Draft",
        sent_to=old_aps.sent_to,
        created_by=request.user
    )

    # --------------------------------------------------
    # 5. LOG
    # --------------------------------------------------

    create_log(
        module_name="Carton Program",
        record_id=new_program.id,
        action="Copied",
        message=f"Program {old_program.program_name} copied to {new_program.program_name}",
        user=request.user
    )

    return Response(
        {
            "message": "Program copied successfully",
            "new_program_id": new_program.id,
            "new_activity_status_id": new_aps.id
        },
        status=201
    )


# ------------------------------------------------------------------
# API: Recall Activity Program
# Description:
#   Resets the status of an Activity Program to "Draft".
#   Used when user clicks Recall button.
#
# Input:
#   activity_program_status_id
#
# Output:
#   Success message
# ------------------------------------------------------------------



recall_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["activity_program_status_id"],
    properties={
        "activity_program_status_id": openapi.Schema(
            type=openapi.TYPE_INTEGER,
            description="ID of Activity Program Status record"
        )
    }
)



@swagger_auto_schema(
    method="post",
    operation_summary="This API should be called on Recall button",
    operation_description="Sets activity program status back to Draft",
    request_body=recall_schema,
    responses={
        200: openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                "message": openapi.Schema(type=openapi.TYPE_STRING)
            }
        ),
        404: "Not Found"
    }
)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def recall(request):

    aps_id = request.data.get("activity_program_status_id")

    if not aps_id:
        return Response(
            {"error": "activity_program_status_id is required"},
            status=400
        )

    try:
        aps = ActivityProgramStatus.objects.get(id=aps_id)
    except ActivityProgramStatus.DoesNotExist:
        return Response(
            {"error": "Invalid activity_program_status_id"},
            status=404
        )

    aps.status = "Draft"
    aps.save()

    create_log(
        module_name="Activity Status",
        record_id=aps.id,
        action="Recalled",
        message=f"Status reset to Draft for program {aps.program.program_name}",
        user=request.user
    )

    return Response(
        {"message": "Status changed to Draft"},
        status=200
    )


# ------------------------------------------------------------------
# API: Edit Carton Program
# ------------------------------------------------------------------
# Description:
#   Updates an existing Carton Program including:
#
#   - Common Carton Program fields
#   - Product-specific details (based on program_type)
#   - Sub Programs (replaced)
#   - Sample Programs (replaced)
#   - Activity Status (optional update)
#
#   Supports:
#   - TOWEL
#   - BEDSHEET
#   - TERRY_TOWEL
#   - BATH_ROBE
#
#   If program_type changes:
#   - Old product-specific model is deleted
#   - New product-specific model is created
# ------------------------------------------------------------------

edit_carton_program_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["activity_program_status_id"],
    properties={

        "activity_program_status_id": openapi.Schema(type=openapi.TYPE_INTEGER),

        "program_type": openapi.Schema(
            type=openapi.TYPE_STRING,
            enum=["TOWEL", "BEDSHEET", "TERRY_TOWEL", "BATH_ROBE"]
        ),

        "btn": openapi.Schema(type=openapi.TYPE_STRING),
        "sent_to_user_id": openapi.Schema(type=openapi.TYPE_INTEGER),

        "carton_program": carton_program_schema,

        "subprograms": openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=subprogram_schema
        ),

        "samples": openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=sample_schema
        ),

        "bedsheet_details": bedsheet_details_schema,
        "terry_details": terry_details_schema,
        "bathrobe_details": bathrobe_details_schema,
    }
)


edit_carton_program_response_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "message": openapi.Schema(type=openapi.TYPE_STRING)
    }
)


@swagger_auto_schema(
    method="post",
    operation_summary="Edit Carton Program (All Product Types)",
    request_body=edit_carton_program_schema,
)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
@transaction.atomic
def edit_carton_program(request):

    data = request.data
    aps_id = data.get("activity_program_status_id")

    if not aps_id:
        return Response(
            {"error": "activity_program_status_id is required"},
            status=400
        )

    try:
        aps = ActivityProgramStatus.objects.select_related(
            "program"
        ).get(id=aps_id)
    except ActivityProgramStatus.DoesNotExist:
        return Response(
            {"error": "Invalid activity_program_status_id"},
            status=404
        )

    program = aps.program
    old_program_type = program.program_type
    new_program_type = data.get("program_type", old_program_type)

    carton_program_data = data.get("carton_program", {})
    subprograms = data.get("subprograms", [])
    samples = data.get("samples", [])

    # --------------------------------------------------
    # 1️⃣ UPDATE COMMON PROGRAM FIELDS
    # --------------------------------------------------

    program.program_type = new_program_type
    program.customer_name = carton_program_data.get("customer_name")
    program.customer_protocol = carton_program_data.get("customer_protocol")
    program.confirm_new_or_shifted_from_vapi = carton_program_data.get("confirm_new_or_shifted_from_vapi")
    program.original_towel = carton_program_data.get("original_towel")
    program.polybag_manual_or_automatic = carton_program_data.get("polybag_manual_or_automatic")
    program.polybag_type = carton_program_data.get("polybag_type")

    program.pallet_or_slipsheet_requirement = carton_program_data.get("pallet_or_slipsheet_requirement")
    program.special_carton_required = carton_program_data.get("special_carton_required")
    program.pdq_required = carton_program_data.get("pdq_required")
    program.cdu_required = carton_program_data.get("cdu_required")

    program.sample_arranged_for_special_carton = carton_program_data.get("sample_carton_arranged")
    program.sample_arranged_for_special_carton_pdq = carton_program_data.get("pdq_arranged")
    program.sample_arranged_for_special_carton_cdu = carton_program_data.get("cdu_arranged")

    program.shipped_as_single_pdq_or_monster_pdq = carton_program_data.get("shipped_as_single_pdq_or_monster_pdq")
    program.pdq_layers_stacking_details = carton_program_data.get("pdq_layers_stacking_details")
    program.common_pdq_same_dimension_for_all_sizes = carton_program_data.get("common_pdq_same_dimension_for_all_sizes")

    program.small_pdq_on_pallet_or_slipsheet = carton_program_data.get("small_pdq_on_pallet_or_slipsheet")
    program.small_pdq_count_on_pallet_or_slipsheet = carton_program_data.get("small_pdq_count_on_pallet_or_slipsheet")
    program.warehouse_store_handling_method = carton_program_data.get("warehouse_store_handling_method")

    program.towel_folded_and_poly_packed_before_carton = carton_program_data.get("towel_folded_and_poly_packed_before_carton")
    program.separator_protector_stiffener_required = carton_program_data.get("separator_protector_stiffener_required")
    program.ribbon_packing_required = carton_program_data.get("ribbon_packing_required")
    program.belly_band_packing_required = carton_program_data.get("belly_band_packing_required")

    program.updated_by = request.user
    program.save()

    # --------------------------------------------------
    # 2️⃣ HANDLE PRODUCT-SPECIFIC MODEL
    # --------------------------------------------------

    # If type changed → delete old detail model
    if old_program_type != new_program_type:

        if old_program_type == "BEDSHEET":
            BedsheetProgramDetails.objects.filter(carton_program=program).delete()

        elif old_program_type == "TERRY_TOWEL":
            TerryTowelProgramDetails.objects.filter(carton_program=program).delete()

        elif old_program_type == "BATH_ROBE":
            BathRobeProgramDetails.objects.filter(carton_program=program).delete()

    # Update or Create new detail model

    if new_program_type == "BEDSHEET":

        details, created = BedsheetProgramDetails.objects.get_or_create(
            carton_program=program
        )

        bd = data.get("bedsheet_details", {})

        details.fabric_tc = bd.get("fabric_tc")
        details.folding_details = bd.get("folding_details")
        details.required_pcs_per_polybag = bd.get("required_pcs_per_polybag")
        details.polybag_size = bd.get("polybag_size")
        details.product_type = bd.get("product_type")
        details.special_packing_requirement = bd.get("special_packing_requirement")
        details.packing_type = bd.get("packing_type")
        details.product_dimension = bd.get("product_dimension")
        details.fold_size = bd.get("fold_size")
        details.blister_packing_required = bd.get("blister_packing_required")
        details.blister_packing_details = bd.get("blister_packing_details")
        details.bag_type = bd.get("bag_type")
        details.special_box_required = bd.get("special_box_required")
        details.required_sets_per_carton = bd.get("required_sets_per_carton")
        details.polyfold_condition = bd.get("polyfold_condition")
        details.filled_product_gsm = bd.get("filled_product_gsm")

        details.save()

    elif new_program_type == "TERRY_TOWEL":

        details, created = TerryTowelProgramDetails.objects.get_or_create(
            carton_program=program
        )

        td = data.get("terry_details", {})

        details.towel_sizes = td.get("towel_sizes")
        details.required_pcs_carton_size = td.get("required_pcs_carton_size")
        details.required_polybags_carton_size = td.get("required_polybags_carton_size")
        details.towel_dimensions = td.get("towel_dimensions")
        details.towel_weight_per_piece = td.get("towel_weight_per_piece")
        details.folding_details = td.get("folding_details")
        details.required_pcs_per_polybag = td.get("required_pcs_per_polybag")
        details.special_carton_details = td.get("special_carton_details")

        details.save()

    elif new_program_type == "BATH_ROBE":

        details, created = BathRobeProgramDetails.objects.get_or_create(
            carton_program=program
        )

        br = data.get("bathrobe_details", {})

        details.original_bath_robe = br.get("original_bath_robe")
        details.bath_robe_sizes = br.get("bath_robe_sizes")
        details.bath_robe_dimensions = br.get("bath_robe_dimensions")
        details.bath_robe_weight = br.get("bath_robe_weight")
        details.folding_details = br.get("folding_details")
        details.required_pcs_per_polybag = br.get("required_pcs_per_polybag")
        details.required_pcs_per_carton = br.get("required_pcs_per_carton")
        details.polybag_type = br.get("polybag_type")
        details.polybag_size_carton = br.get("polybag_size_carton")

        details.save()

    # --------------------------------------------------
    # 3️⃣ UPDATE ACTIVITY STATUS (OPTIONAL)
    # --------------------------------------------------

    new_status = data.get("btn")
    new_sent_to = data.get("sent_to_user_id")

    if new_status:
        aps.status = new_status

    if new_sent_to:
        aps.sent_to_id = new_sent_to

    aps.save()

    # --------------------------------------------------
    # 4️⃣ REPLACE SUBPROGRAMS
    # --------------------------------------------------

    CartonProgramSubProgram.objects.filter(
        carton_program=program
    ).delete()

    calc = CartonCalculator()

    for sp in subprograms:

        # Recompute folded/carton dims consistently instead of leaving them
        # blank (previously edit_carton_program never called the calculator,
        # so folded_length/folded_width/carton_length/width/height were
        # silently wiped to null on every edit).
        result = calc.compute(sp)

        ribbon_val, err = _validate_yes_no(sp.get("ribbon"), "ribbon")
        if err:
            return err

        belly_band_val, err = _validate_yes_no(sp.get("belly_band"), "belly_band")
        if err:
            return err

        self_fabric_bag_val, err = _validate_yes_no(sp.get("self_fabric_bag"), "self_fabric_bag")
        if err:
            return err

        width_cm = sp.get("width_cm")
        length_cm = sp.get("length_cm")

        if width_cm is None and sp.get("width_in") is not None:
            width_cm = round(Decimal(str(sp.get("width_in"))) * Decimal("2.54"), 2)

        if length_cm is None and sp.get("length_in") is not None:
            length_cm = round(Decimal(str(sp.get("length_in"))) * Decimal("2.54"), 2)

        CartonProgramSubProgram.objects.create(
            carton_program=program,
            program_name=sp.get("program_name"),
            style=sp.get("style"),

            size=sp.get("size"),
            product_type=sp.get("product_type"),

            width_in=sp.get("width_in"),
            length_in=sp.get("length_in"),
            width_cm=width_cm,
            length_cm=length_cm,

            wt_per_unit=sp.get("wt_per_unit") or result["weight"],
            weight_uom=sp.get("weight_uom", "GM"),

            gsm=sp.get("gsm"),
            unit_per_carton=sp.get("unit_per_carton"),
            inner_pack_unit_qty=sp.get("inner_pack_unit_qty"),
            fold=sp.get("fold"),

            ribbon=ribbon_val,
            belly_band=belly_band_val,
            self_fabric_bag=self_fabric_bag_val,

            folded_length=result["folded_length"],
            folded_width=result["folded_width"],
            carton_length=result["carton"]["length"],
            carton_width=result["carton"]["width"],
            carton_height=result["carton"]["height"],
        )

    # --------------------------------------------------
    # 5️⃣ REPLACE SAMPLE PROGRAMS
    # --------------------------------------------------

    SampleProgram.objects.filter(
        carton_program=program
    ).delete()

    for sm in samples:
        SampleProgram.objects.create(
            carton_program=program,
            program_name=sm.get("program_name"),
            size=sm.get("size"),
            sample=sm.get("sample"),
            quality=sm.get("quality"),
            lbs_per_dz=sm.get("lbs_per_dz"),
            gsm=sm.get("gsm"),
            shade=sm.get("shade"),
            width_in=sm.get("width_in"),
            length_in=sm.get("length_in"),
            width_cm=sm.get("width_cm"),
            length_cm=sm.get("length_cm"),
        )

    # --------------------------------------------------
    # 6️⃣ LOG
    # --------------------------------------------------

    create_log(
        module_name="Carton Program",
        record_id=program.id,
        action="Updated",
        message=f"Program updated (Type: {new_program_type})",
        user=request.user
    )

    return Response(
        {"message": "Carton Program Updated Successfully"},
        status=200
    )




# ------------------------------------------------------------------
# API: Get Carton Program Full Details
# ------------------------------------------------------------------
# Description:
#   Returns complete data of a Carton Program including:
#
#   - Activity details
#   - Common Carton Program fields
#   - Product-specific details (based on program_type)
#   - Sub Programs
#   - Sample Programs
#   - Attachments
#
#   Supports:
#   - TOWEL
#   - BEDSHEET
#   - TERRY_TOWEL
#   - BATH_ROBE
#
#   Dynamically includes product-specific model data.
# ------------------------------------------------------------------


get_carton_program_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["activity_program_status_id"],
    properties={
        "activity_program_status_id": openapi.Schema(
            type=openapi.TYPE_INTEGER,
            description="ActivityProgramStatus ID"
        )
    }
)
get_carton_program_response_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "activity": openapi.Schema(type=openapi.TYPE_STRING),
        "status": openapi.Schema(type=openapi.TYPE_STRING),
        "program_type": openapi.Schema(type=openapi.TYPE_STRING),
        "sent_to_user_id": openapi.Schema(type=openapi.TYPE_INTEGER),

        "carton_program": openapi.Schema(type=openapi.TYPE_OBJECT),

        "bedsheet_details": openapi.Schema(type=openapi.TYPE_OBJECT),
        "terry_details": openapi.Schema(type=openapi.TYPE_OBJECT),
        "bathrobe_details": openapi.Schema(type=openapi.TYPE_OBJECT),

        "subprograms": openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=openapi.Schema(type=openapi.TYPE_OBJECT)
        ),

        "samples": openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=openapi.Schema(type=openapi.TYPE_OBJECT)
        ),

        "attachments": openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=openapi.Schema(type=openapi.TYPE_OBJECT)
        ),
    }
)

@swagger_auto_schema(
    method="post",
    operation_summary="Get Carton Program Full Details",
    request_body=get_carton_program_schema,
)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def get_carton_program_details(request):

    aps_id = request.data.get("activity_program_status_id")

    if not aps_id:
        return Response(
            {"error": "activity_program_status_id is required"},
            status=400
        )

    try:
        aps = ActivityProgramStatus.objects.select_related(
            "program"
        ).get(id=aps_id)
    except ActivityProgramStatus.DoesNotExist:
        return Response(
            {"error": "Invalid activity_program_status_id"},
            status=404
        )

    program = aps.program
    program_type = program.program_type
    

    # --------------------------------------------------
    # PRODUCT SPECIFIC DETAILS
    # --------------------------------------------------

    bedsheet_details = None
    terry_details = None
    bathrobe_details = None

    if program_type == "BEDSHEET":
        try:
            bd = program.bedsheet_details
            bedsheet_details = {
                "fabric_tc": bd.fabric_tc,
                "folding_details": bd.folding_details,
                "required_pcs_per_polybag": bd.required_pcs_per_polybag,
                "polybag_size": bd.polybag_size,
                "product_type": bd.product_type,
                "special_packing_requirement": bd.special_packing_requirement,
                "packing_type": bd.packing_type,
                "product_dimension": bd.product_dimension,
                "fold_size": bd.fold_size,
                "blister_packing_required": bd.blister_packing_required,
                "blister_packing_details": bd.blister_packing_details,
                "bag_type": bd.bag_type,
                "special_box_required": bd.special_box_required,
                "required_sets_per_carton": bd.required_sets_per_carton,
                "polyfold_condition": bd.polyfold_condition,
                "filled_product_gsm": bd.filled_product_gsm,
            }
        except:
            bedsheet_details = {}

    elif program_type == "TERRY_TOWEL":
        try:
            td = program.terry_details
            terry_details = {
                "towel_sizes": td.towel_sizes,
                "required_pcs_carton_size": td.required_pcs_carton_size,
                "required_polybags_carton_size": td.required_polybags_carton_size,
                "towel_dimensions": td.towel_dimensions,
                "towel_weight_per_piece": td.towel_weight_per_piece,
                "folding_details": td.folding_details,
                "required_pcs_per_polybag": td.required_pcs_per_polybag,
                "special_carton_details": td.special_carton_details,
            }
        except:
            terry_details = {}

    elif program_type == "BATH_ROBE":
        try:
            br = program.bathrobe_details
            bathrobe_details = {
                "original_bath_robe": br.original_bath_robe,
                "bath_robe_sizes": br.bath_robe_sizes,
                "bath_robe_dimensions": br.bath_robe_dimensions,
                "bath_robe_weight": br.bath_robe_weight,
                "folding_details": br.folding_details,
                "required_pcs_per_polybag": br.required_pcs_per_polybag,
                "required_pcs_per_carton": br.required_pcs_per_carton,
                "polybag_type": br.polybag_type,
                "polybag_size_carton": br.polybag_size_carton,
            }
        except:
            bathrobe_details = {}

    # --------------------------------------------------
    # SUBPROGRAMS
    # --------------------------------------------------

    subprogram_list = []

    subs = CartonProgramSubProgram.objects.filter(
        carton_program=program
    )

    for sp in subs:
        subprogram_list.append({
            "subprogram_id": sp.id,
            "program_name": sp.program_name,
            "style": sp.style,
            "pcs_per_set": sp.pcs_per_set,

            # NEW
            "size": sp.size,
            "size_display": sp.get_size_display() if sp.size else None,
            "product_type": sp.product_type,
            "product_type_display": sp.get_product_type_display() if sp.product_type else None,
            "size_display_label": sp.size_display_label,

            "width_in": sp.width_in,
            "length_in": sp.length_in,
            "width_cm": sp.width_cm,
            "length_cm": sp.length_cm,

            "folded_length": sp.folded_length,
            "folded_width": sp.folded_width,

            "wt_per_unit": sp.wt_per_unit,
            "weight_uom": sp.weight_uom,
            "gsm": sp.gsm,

            "unit_per_carton": sp.unit_per_carton,
            "inner_pack_unit_qty": sp.inner_pack_unit_qty,
            "fold": sp.fold,

            "carton_length": sp.carton_length,
            "carton_width": sp.carton_width,
            "carton_height": sp.carton_height,

            "ribbon": sp.ribbon,
            "belly_band": sp.belly_band,
            "self_fabric_bag": sp.self_fabric_bag,
            "remark": sp.remark,

            # Frontend should grey out Tentative/Final submit unless this is
            # true for every subprogram (call get_carton_calculations_ai /
            # Recalculate to set it).
            "is_recalculated": sp.is_recalculated,
            "last_recalculated_on": (
                sp.last_recalculated_on.strftime("%d-%m-%Y %H:%M:%S")
                if sp.last_recalculated_on else None
            ),

            "pdq_length": sp.pdq_length,
            "pdq_width": sp.pdq_width,
            "pdq_height": sp.pdq_height,
            "net_wt_pdq": sp.net_wt_pdq,
            "pallet_wt_pdq": sp.pallet_wt_pdq,

            "pallet_length": sp.pallet_length,
            "pallet_width": sp.pallet_width,
            "pallet_height": sp.pallet_height,
            
            "packed_pb_length": sp.packed_pb_length,
            "packed_pb_width": sp.packed_pb_width,
            "packed_pb_height": sp.packed_pb_height,

            "calculated_net_wt_carton": sp.calculated_net_wt_carton,
            "calculated_cbm_per_carton": sp.calculated_cbm_per_carton,
            "calculated_cbm_per_pdq": sp.calculated_cbm_per_pdq,

            "cartons_per_20ft": sp.cartons_per_container("20FT"),
            "cartons_per_40ft": sp.cartons_per_container("40FT"),
            "pdq_per_20ft": sp.pdq_per_container("20FT"),
            "pdq_per_40ft": sp.pdq_per_container("40FT"),
            "pallet_per_20ft": sp.pallets_per_container("20FT"),
            "pallet_per_40ft": sp.pallets_per_container("40FT"),
        })

    # --------------------------------------------------
    # SAMPLE PROGRAMS
    # --------------------------------------------------

    sample_list = []

    samples = SampleProgram.objects.filter(
        carton_program=program
    )

    for sm in samples:
        sample_list.append({
            "program_name": sm.program_name,
            "size": sm.size,
            "sample": sm.sample,
            "quality": sm.quality,
            "lbs_per_dz": sm.lbs_per_dz,
            "gsm": sm.gsm,
            "shade": sm.shade,
            "width_in": sm.width_in,
            "length_in": sm.length_in,
            "width_cm": sm.width_cm,
            "length_cm": sm.length_cm,
        })

    # --------------------------------------------------
    # ATTACHMENTS
    # --------------------------------------------------

    attachments = []

    for att in program.attachments.all():
        attachments.append({
            "id": att.id,
            "file_url": request.build_absolute_uri(att.file.url),
            "description": att.description,
            "uploaded_on": att.uploaded_on.strftime("%d-%m-%Y")
        })

    # --------------------------------------------------
    # FINAL RESPONSE
    # --------------------------------------------------

    response_data = {
        "activity": aps.activity,
        "status": aps.status,
        "program_type": program_type,
        "sent_to_user_id": aps.sent_to_id,

        "carton_program": {
            "program_name": program.program_name,
            "customer_name": program.customer_name,
            "customer_protocol": program.customer_protocol,
            "confirm_new_or_shifted_from_vapi": program.confirm_new_or_shifted_from_vapi,
            "original_towel": program.original_towel,
            "polybag_manual_or_automatic": program.polybag_manual_or_automatic,
            "polybag_type": program.polybag_type,
            "pallet_or_slipsheet_requirement": program.pallet_or_slipsheet_requirement,
            "special_carton_required": program.special_carton_required,
            "pdq_required": program.pdq_required,
            "cdu_required": program.cdu_required,
            "sample_carton_arranged": program.sample_arranged_for_special_carton,
            "pdq_arranged": program.sample_arranged_for_special_carton_pdq,
            "cdu_arranged": program.sample_arranged_for_special_carton_cdu,
            "shipped_as_single_pdq_or_monster_pdq": program.shipped_as_single_pdq_or_monster_pdq,
            "pdq_layers_stacking_details": program.pdq_layers_stacking_details,
            "common_pdq_same_dimension_for_all_sizes": program.common_pdq_same_dimension_for_all_sizes,
            "small_pdq_on_pallet_or_slipsheet": program.small_pdq_on_pallet_or_slipsheet,
            "small_pdq_count_on_pallet_or_slipsheet": program.small_pdq_count_on_pallet_or_slipsheet,
            "warehouse_store_handling_method": program.warehouse_store_handling_method,
            "towel_folded_and_poly_packed_before_carton": program.towel_folded_and_poly_packed_before_carton,
            "separator_protector_stiffener_required": program.separator_protector_stiffener_required,
            "ribbon_packing_required": program.ribbon_packing_required,
            "belly_band_packing_required": program.belly_band_packing_required,
            "remark": program.remark
        },

        "bedsheet_details": bedsheet_details,
        "terry_details": terry_details,
        "bathrobe_details": bathrobe_details,

        "subprograms": subprogram_list,
        "samples": sample_list,
        "attachments": attachments,
    }

    return Response(response_data)



# ------------------------------------------------------------------
# API: My Assigned Activities
#
# Description:
#   Returns all non-draft activities assigned to logged-in user.
#
#   Includes:
#   - Program name
#   - Customer
#   - Program type (for dynamic form rendering)
#   - Status
#   - Created timestamp
#
# Excludes:
#   - Draft
#   - Save as Draft
#
# Method: GET
# ------------------------------------------------------------------


# ------------------------------------------------------------------
# Swagger Schema: My Assigned Activities Response
# ------------------------------------------------------------------

my_assigned_activities_response_schema = openapi.Schema(
    type=openapi.TYPE_ARRAY,
    items=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            "activity_program_status_id": openapi.Schema(
                type=openapi.TYPE_INTEGER
            ),
            "activity": openapi.Schema(
                type=openapi.TYPE_STRING
            ),
            "program_name": openapi.Schema(
                type=openapi.TYPE_STRING
            ),
            "customer_name": openapi.Schema(
                type=openapi.TYPE_STRING
            ),
            "program_type": openapi.Schema(
                type=openapi.TYPE_STRING,
                description="TOWEL / BEDSHEET / TERRY TOWEL / BATH ROBE"
            ),
            "status": openapi.Schema(
                type=openapi.TYPE_STRING
            ),
            "created_on": openapi.Schema(
                type=openapi.TYPE_STRING,
                description="Formatted datetime: DD-MM-YYYY HH:MM:SS"
            ),
        }
    )
)


@swagger_auto_schema(
    method="get",
    operation_summary="Get My Assigned Activities",
    operation_description="Returns all non-draft activities assigned to logged-in user.",
    responses={
        200: my_assigned_activities_response_schema,
        401: "Unauthorized"
    }
)
@api_view(["GET"])
@permission_classes([IsAuthenticated])
def my_assigned_activities(request):

    records = ActivityProgramStatus.objects.select_related(
        "program"
    ).filter(
        sent_to=request.user
    ).exclude(
        status__icontains="draft"
    )

    data = []

    for r in records:
        data.append({
            "activity_program_status_id": r.id,
            "program_id": r.program.id,
            "activity": r.activity,
            "program_name": r.program.program_name,
            "customer_name": r.program.customer_name,
            "program_type": r.program.program_type,
            "status": r.status,
            "created_on": r.created_on.strftime("%d-%m-%Y %H:%M:%S")
            if r.created_on else None,
        })

    return Response(data)




# ------------------------------------------------------------------
# API: Accept Carton Program
# Description:
#   Sets status to In Progress
# ------------------------------------------------------------------


accept_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["activity_program_status_id"],
    properties={
        "activity_program_status_id": openapi.Schema(type=openapi.TYPE_INTEGER)
    }
)



@swagger_auto_schema(
    method="post",
    operation_summary="Accept assigned program",
    request_body=accept_schema,
    responses={200: "Accepted"}
)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def accept_program(request):

    aps_id = request.data.get("activity_program_status_id")

    try:
        aps = ActivityProgramStatus.objects.get(
            id=aps_id,
            sent_to=request.user
        )
    except ActivityProgramStatus.DoesNotExist:
        return Response({"error": "Invalid record"}, status=404)

    aps.status = "In Progress"
    aps.rejection_reason = None
    aps.save()

    create_log(
        module_name="Activity Status",
        record_id=aps.id,
        action="Accepted",
        message=f"Program {aps.program.program_name} accepted",
        user=request.user
    )

    return Response({"message": "Program Accepted"})



# ------------------------------------------------------------------
# API: Accept Carton Program PPC
# Description:
#   Sets status to In Progress and assign to tqm (id 3)
# ------------------------------------------------------------------


accept_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["activity_program_status_id"],
    properties={
        "activity_program_status_id": openapi.Schema(type=openapi.TYPE_INTEGER)
    }
)



@swagger_auto_schema(
    method="post",
    operation_summary="PPC Accept assigned program",
    request_body=accept_schema,
    responses={200: "Accepted By PPC"}
)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def accept_program_ppc(request):
    User = get_user_model()

    aps_id = request.data.get("activity_program_status_id")

    try:
        aps = ActivityProgramStatus.objects.get(
            id=aps_id,
            sent_to=request.user
        )
    except ActivityProgramStatus.DoesNotExist:
        return Response({"error": "Invalid record"}, status=404)
    
    try:
        tqm_user = User.objects.get(id=5)
    except User.DoesNotExist:
        return Response({"error": "TQM user not found"}, status=404)

    aps.status = "In Progress"
    aps.sent_to = tqm_user
    aps.rejection_reason = None
    aps.save()
    

    notification = NotificationService()
    
    try:
        notification.send_tqm_notification(aps.program)
    except Exception as e:
        print("Email failed:", str(e))

    create_log(
        module_name="Activity Status",
        record_id=aps.id,
        action="Accepted_PPC",
        message=f"Program {aps.program.program_name} accepted by ppc",
        user=request.user
    )

    return Response({"message": "Program Accepted By PPC"})
 


# ------------------------------------------------------------------
# API: Reject Carton Program
# Description:
#   Sets status to Rejected with reason
# ------------------------------------------------------------------


reject_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["activity_program_status_id", "reason"],
    properties={
        "activity_program_status_id": openapi.Schema(type=openapi.TYPE_INTEGER),
        "reason": openapi.Schema(type=openapi.TYPE_STRING)
    }
)

@swagger_auto_schema(
    method="post",
    operation_summary="Reject assigned program",
    request_body=reject_schema,
    responses={200: "Rejected"}
)




@api_view(["POST"])
@permission_classes([IsAuthenticated])
def reject_program(request):

    aps_id = request.data.get("activity_program_status_id")
    reason = request.data.get("reason")

    if not reason:
        return Response({"error": "reason is required"}, status=400)

    try:
        aps = ActivityProgramStatus.objects.get(
            id=aps_id,
            sent_to=request.user
        )
    except ActivityProgramStatus.DoesNotExist:
        return Response({"error": "Invalid record"}, status=404)

    aps.status = "Rejected"
    aps.rejection_reason = reason
    aps.save()
    

    notification = NotificationService()

    # Notify creator
    try:
        notification.send_rejection_notification(
            aps.program,
            reason
        )
    except Exception as e:
        print("Email failed:", str(e))

    create_log(
        module_name="Activity Status",
        record_id=aps.id,
        action="Rejected",
        message=f"Rejected: {reason}",
        user=request.user
    )

    return Response({"message": "Program Rejected"})



# ------------------------------------------------------------------
# API: Bulk Update TQM Subprogram Details
# Description:
#   Allows TQM user to update carton, PDQ and pallet details
#   for multiple subprograms in one request.
#
#   Updates:
#   - Carton dimensions
#   - PDQ dimensions
#   - Pallet dimensions
#   - Packing flags
#   - Activity status
#
#   Conditional Rules:
#   - If pdq_required = True → PDQ fields mandatory
#   - If pallet_or_slipsheet_requirement = True → Pallet size mandatory
#
#   Container calculations are automatically derived
#   from model properties after saving.
# ------------------------------------------------------------------
tqm_bulk_update_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["activity_program_status_id", "btn", "subprograms"],
    properties={

        "activity_program_status_id": openapi.Schema(
            type=openapi.TYPE_INTEGER
        ),

        "btn": openapi.Schema(
            type=openapi.TYPE_STRING,
            enum=["tentative_submit", "final_submit"]
        ),

        "request_sample": openapi.Schema(type=openapi.TYPE_BOOLEAN),
        "request_carton_sizing": openapi.Schema(type=openapi.TYPE_BOOLEAN),

        "purchase_sent_to": openapi.Schema(
            type=openapi.TYPE_INTEGER
        ),

        "subprograms": openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=openapi.Schema(
                type=openapi.TYPE_OBJECT,
                required=["subprogram_id"],
                properties={

                    "subprogram_id": openapi.Schema(type=openapi.TYPE_INTEGER),

                    # Carton
                    "carton_length": openapi.Schema(type=openapi.TYPE_NUMBER, description="cm"),
                    "carton_width": openapi.Schema(type=openapi.TYPE_NUMBER, description="cm"),
                    "carton_height": openapi.Schema(type=openapi.TYPE_NUMBER, description="cm"),

                    # NEW: weight is now editable by TQM (weight per piece)
                    "wt_per_unit": openapi.Schema(type=openapi.TYPE_NUMBER),
                    "weight_uom": openapi.Schema(
                        type=openapi.TYPE_STRING,
                        enum=["GM", "KG", "LB"]
                    ),

                    "ribbon": openapi.Schema(
                        type=openapi.TYPE_STRING,
                        enum=["YES", "NO"]
                    ),
                    "belly_band": openapi.Schema(
                        type=openapi.TYPE_STRING,
                        enum=["YES", "NO"]
                    ),
                    "self_fabric_bag": openapi.Schema(
                        type=openapi.TYPE_STRING,
                        enum=["YES", "NO"]
                    ),
                    "remark": openapi.Schema(type=openapi.TYPE_STRING),

                    # PDQ
                    "pdq_length": openapi.Schema(type=openapi.TYPE_NUMBER),
                    "pdq_width": openapi.Schema(type=openapi.TYPE_NUMBER),
                    "pdq_height": openapi.Schema(type=openapi.TYPE_NUMBER),
                    "net_wt_pdq": openapi.Schema(type=openapi.TYPE_NUMBER),
                    "pallet_wt_pdq": openapi.Schema(type=openapi.TYPE_NUMBER),

                    # Pallet
                    "pallet_length": openapi.Schema(type=openapi.TYPE_NUMBER),
                    "pallet_width": openapi.Schema(type=openapi.TYPE_NUMBER),
                    "pallet_height": openapi.Schema(type=openapi.TYPE_NUMBER),
                    
                    # Packed PB
                    "packed_pb_length": openapi.Schema(type=openapi.TYPE_NUMBER),
                    "packed_pb_width": openapi.Schema(type=openapi.TYPE_NUMBER),
                    "packed_pb_height": openapi.Schema(type=openapi.TYPE_NUMBER),
                }
            )
        )
    }
)

tqm_bulk_update_response = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "message": openapi.Schema(type=openapi.TYPE_STRING)
    }
)


tqm_bulk_update_response = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "message": openapi.Schema(
            type=openapi.TYPE_STRING,
            example="TQM subprogram details updated successfully"
        )
    }
)

@swagger_auto_schema(
    method="post",
    operation_summary="Bulk Update TQM Subprogram",
    request_body=tqm_bulk_update_schema,
    responses={200: tqm_bulk_update_response}
)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
@transaction.atomic
def bulk_update_tqm_subprogram(request):

    data = request.data

    aps_id = data.get("activity_program_status_id")
    btn = data.get("btn")
    request_sample = data.get("request_sample")
    request_carton_sizing = data.get("request_carton_sizing")
    purchase_sent_to = data.get("purchase_sent_to")
    subprograms = data.get("subprograms", [])
    
    inner_pack_unit_qty = data.get("inner_pack_unit_qty")

    if not aps_id:
        return Response(
            {"error": "activity_program_status_id is required"},
            status=400
        )

    if not subprograms:
        return Response(
            {"error": "subprograms list is required"},
            status=400
        )

    # --------------------------------------------------
    # FETCH ACTIVITY STATUS
    # --------------------------------------------------

    try:
        aps = ActivityProgramStatus.objects.select_related(
            "program"
        ).get(
            id=aps_id,
            sent_to=request.user
        )
    except ActivityProgramStatus.DoesNotExist:
        return Response(
            {"error": "Invalid record"},
            status=404
        )

    program = aps.program

    pallet_required = program.pallet_or_slipsheet_requirement
    pdq_required = program.pdq_required
    

    # --------------------------------------------------
    # RECALCULATE GATE (checked BEFORE any save happens)
    # --------------------------------------------------
    # Tentative/Final submit is only allowed once TQM has clicked
    # "Recalculate" (which calls get_carton_calculations_ai - see below,
    # which sets is_recalculated=True on every subprogram in this program)
    # AFTER their latest dimension edits. If any subprogram in this request
    # is not currently marked recalculated, block the submit here - as a
    # server-side backstop for the frontend's greyed-out button - before
    # touching the activity status or any subprogram row.
    # --------------------------------------------------

    if btn in ("tentative_submit", "final_submit"):
        sp_ids = [item.get("subprogram_id") for item in subprograms]
        not_recalculated = CartonProgramSubProgram.objects.filter(
            id__in=sp_ids,
            carton_program=program,
            is_recalculated=False
        ).values_list("id", flat=True)

        if not_recalculated:
            return Response(
                {
                    "error": "Please click Recalculate before submitting.",
                    "subprogram_ids_needing_recalculation": list(not_recalculated)
                },
                status=400
            )

    # --------------------------------------------------
    # UPDATE STATUS FLAGS
    # --------------------------------------------------

    if request_sample is not None:
        aps.request_sample = request_sample

    if request_carton_sizing is not None:
        aps.request_carton_sizing = request_carton_sizing

    if purchase_sent_to:
        aps.purchase_sent_to_id = purchase_sent_to

    if btn == "final_submit":
        aps.status = "Final Working Submitted"
    else:
        aps.status = "Tentative Working Submitted"

    aps.rejection_reason = None
    aps.save()

    # --------------------------------------------------
    # LOOP SUBPROGRAMS
    # --------------------------------------------------

    for item in subprograms:

        sp_id = item.get("subprogram_id")

        try:
            sp = CartonProgramSubProgram.objects.get(
                id=sp_id,
                carton_program=program
            )
        except CartonProgramSubProgram.DoesNotExist:
            return Response(
                {"error": f"Invalid subprogram_id {sp_id}"},
                status=404
            )

        # ------------------------------
        # CONDITIONAL VALIDATION
        # ------------------------------

        if pdq_required:
            if not item.get("pdq_length") or not item.get("pdq_width") or not item.get("pdq_height"):
                return Response(
                    {"error": f"PDQ details mandatory for subprogram {sp_id}"},
                    status=400
                )

        if pallet_required:
            if not item.get("pallet_length") or not item.get("pallet_width") or not item.get("pallet_height"):
                return Response(
                    {"error": f"Pallet size mandatory for subprogram {sp_id}"},
                    status=400
                )
                
                
        if inner_pack_unit_qty and inner_pack_unit_qty != 0:
            if not item.get("packed_pb_length") or not item.get("packed_pb_width") or not item.get("packed_pb_height"):
                return Response(
                    {"error": f"Packed pb size mandatory for subprogram {sp_id}"},
                    status=400
                )

        # ------------------------------
        # YES/NO DROPDOWN VALIDATION
        # ------------------------------

        ribbon_val, err = _validate_yes_no(item.get("ribbon"), f"ribbon (subprogram {sp_id})")
        if err:
            return err

        belly_band_val, err = _validate_yes_no(item.get("belly_band"), f"belly_band (subprogram {sp_id})")
        if err:
            return err

        self_fabric_bag_val, err = _validate_yes_no(item.get("self_fabric_bag"), f"self_fabric_bag (subprogram {sp_id})")
        if err:
            return err

        # ------------------------------
        # DID DIMENSIONS CHANGE? -> reset recalculate flag
        # ------------------------------
        dims_changed = (
            item.get("carton_length") is not None and str(sp.carton_length) != str(item.get("carton_length"))
        ) or (
            item.get("carton_width") is not None and str(sp.carton_width) != str(item.get("carton_width"))
        ) or (
            item.get("carton_height") is not None and str(sp.carton_height) != str(item.get("carton_height"))
        )

        # ------------------------------
        # SAVE FIELDS
        # ------------------------------

        sp.carton_length = item.get("carton_length")
        sp.carton_width = item.get("carton_width")
        sp.carton_height = item.get("carton_height")

        # Weight is editable here too (weight per piece) - previously TQM
        # had no way to correct this at all.
        if item.get("wt_per_unit") is not None:
            sp.wt_per_unit = item.get("wt_per_unit")
        if item.get("weight_uom"):
            sp.weight_uom = item.get("weight_uom")

        sp.ribbon = ribbon_val
        sp.belly_band = belly_band_val
        sp.self_fabric_bag = self_fabric_bag_val
        sp.remark = item.get("remark")

        sp.pdq_length = item.get("pdq_length")
        sp.pdq_width = item.get("pdq_width")
        sp.pdq_height = item.get("pdq_height")

        sp.net_wt_pdq = item.get("net_wt_pdq")
        sp.pallet_wt_pdq = item.get("pallet_wt_pdq")

        sp.pallet_length = item.get("pallet_length")
        sp.pallet_width = item.get("pallet_width")
        sp.pallet_height = item.get("pallet_height")
        
        sp.packed_pb_length = item.get("packed_pb_length")
        sp.packed_pb_width = item.get("packed_pb_width")
        sp.packed_pb_height = item.get("packed_pb_height")

        if dims_changed:
            sp.is_recalculated = False

        sp.save()

        create_log(
            module_name="Sub Program",
            record_id=sp.id,
            action="TQM Updated",
            message="Carton/PDQ/Pallet updated",
            user=request.user
        )

    # --------------------------------------------------
    # FINAL RESPONSE
    # --------------------------------------------------
    
    notification = NotificationService()

    try:
        notification.send_purchase_notification(program)
    except Exception as e:
        print("Email failed:", str(e))

    return Response(
        {"message": "TQM subprogram details updated successfully"},
        status=200
    )


# ------------------------------------------------------------------
# API: Upload Carton Program Attachment
# Description:
#   Uploads file and links it to a carton program
# ------------------------------------------------------------------

@swagger_auto_schema(
    method="post",
    operation_summary="Upload Carton Program Attachment",
    operation_description="Uploads attachment file and links it to a carton program",
    manual_parameters=[
        openapi.Parameter(
            "program_id",
            openapi.IN_FORM,
            type=openapi.TYPE_INTEGER,
            required=True,
            description="CartonProgram ID"
        ),
        openapi.Parameter(
            "file",
            openapi.IN_FORM,
            type=openapi.TYPE_FILE,
            required=True,
            description="Attachment file"
        ),
        openapi.Parameter(
            "description",
            openapi.IN_FORM,
            type=openapi.TYPE_STRING,
            required=False,
            description="Optional description"
        )
    ],
    responses={
        200: openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                "message": openapi.Schema(type=openapi.TYPE_STRING)
            }
        )
    }
)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser, FormParser])   # ✅ THIS LINE
def upload_carton_program_attachment(request):


    program_id = request.data.get("program_id")
    file = request.FILES.get("file")
    description = request.data.get("description", "")

    if not program_id or not file:
        return Response(
            {"error": "program_id and file are required"},
            status=400
        )

    try:
        program = CartonProgram.objects.get(id=program_id)
    except CartonProgram.DoesNotExist:
        return Response(
            {"error": "Invalid program_id"},
            status=404
        )

    CartonProgramAttachment.objects.create(
        program=program,
        file=file,
        description=description
    )

    return Response({"message": "Attachment uploaded successfully"})





purchase_action_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["activity_program_status_id"],
    properties={
        "activity_program_status_id": openapi.Schema(
            type=openapi.TYPE_INTEGER,
            description="ActivityProgramStatus ID"
        )
    }
)


simple_message_response = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "message": openapi.Schema(type=openapi.TYPE_STRING)
    }
)


purchase_list_response_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "activity_program_status_id": openapi.Schema(type=openapi.TYPE_INTEGER),
        "activity": openapi.Schema(type=openapi.TYPE_STRING),
        "program_name": openapi.Schema(type=openapi.TYPE_STRING),
        "customer_name": openapi.Schema(type=openapi.TYPE_STRING),
        "request_type": openapi.Schema(type=openapi.TYPE_STRING),
        "status": openapi.Schema(type=openapi.TYPE_STRING),
        "created_on": openapi.Schema(type=openapi.TYPE_STRING),
    }
)

# ------------------------------------------------------------------
# API: Purchase Assigned Activities
#
# Description:
#   Returns activities where logged-in purchase user
#   has action required.
#
# Includes:
#   - Activity details
#   - Program type (for dynamic rendering)
#   - Request type (Sample / Carton Sizing / Both)
#   - Status
#   - Created timestamp
#
# Method: GET
# ------------------------------------------------------------------

@swagger_auto_schema(
    method="get",
    operation_summary="Purchase Assigned Activities",
    operation_description="Returns activities assigned to logged-in purchase user",
    responses={
        200: openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=purchase_list_response_schema
        ),
        401: "Unauthorized"
    }
)
@api_view(["GET"])
@permission_classes([IsAuthenticated])
def purchase_assigned_activities(request):

    records = ActivityProgramStatus.objects.select_related(
        "program"
    ).filter(
        purchase_sent_to=request.user
    )

    data = []

    for r in records:

        request_type = []

        if r.request_sample:
            request_type.append("Sample")

        if r.request_carton_sizing:
            request_type.append("Carton Sizing")

        data.append({
            "activity_program_status_id": r.id,
            "activity": r.activity,
            "program_name": r.program.program_name,
            "customer_name": r.program.customer_name,
            "program_type": r.program.program_type,   # 🔥 IMPORTANT ADDITION
            "request_type": " + ".join(request_type),
            "status": r.status,
            "created_on": r.created_on.strftime("%d-%m-%Y %H:%M:%S")
            if r.created_on else None,
        })

    return Response(data)

# ------------------------------------------------------------------
# API: Purchase Submit Completion
# Description:
#   Marks request as final submitted
# ------------------------------------------------------------------


@swagger_auto_schema(
    method="post",
    operation_summary="Purchase Submit Completion",
    operation_description="Marks request as final submitted by purchase",
    request_body=purchase_action_schema,
    responses={
        200: simple_message_response,
        400: "Bad Request",
        404: "Not Found"
    }
)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def purchase_submit_completion(request):

    aps_id = request.data.get("activity_program_status_id")

    try:
        aps = ActivityProgramStatus.objects.get(id=aps_id)
    except ActivityProgramStatus.DoesNotExist:
        return Response({"error": "Invalid id"}, status=404)

    aps.status = "Final Working Submitted"
    aps.save()

    try:
        notification = NotificationService()
        notification.send_warehouse_notification(aps.program)
    except Exception as e:
        print("Email failed:", str(e))
    
    create_log(
        module_name="Purchase",
        record_id=aps.id,
        action="Completed",
        message="Purchase completed request",
        user=request.user
    )

    return Response({"message": "Final submitted"})



# ------------------------------------------------------------------
# API: Purchase Accept Request
# Description:
#   Purchase user accepts the requested activity
# ------------------------------------------------------------------


@swagger_auto_schema(
    method="post",
    operation_summary="Purchase Accept Request",
    operation_description="Marks request as accepted by purchase user",
    request_body=purchase_action_schema,
    responses={
        200: simple_message_response,
        400: "Bad Request",
        404: "Not Found"
    }
)

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def purchase_accept_request(request):

    aps_id = request.data.get("activity_program_status_id")

    if not aps_id:
        return Response(
            {"error": "activity_program_status_id is required"},
            status=400
        )

    try:
        aps = ActivityProgramStatus.objects.get(id=aps_id)
    except ActivityProgramStatus.DoesNotExist:
        return Response(
            {"error": "Invalid activity_program_status_id"},
            status=404
        )

    aps.status = "Sample Request Accepted"
    aps.save()

    create_log(
        module_name="Purchase",
        record_id=aps.id,
        action="Accepted",
        message="Purchase accepted the request",
        user=request.user
    )

    return Response({"message": "Request accepted successfully"})



# ------------------------------------------------------------------
# API: Warehouse Dashboard Data
#
# Description:
#   Returns all subprograms where activity status
#   is "Final Working Submitted".
#
#   Includes:
#   - Program information
#   - Product type
#   - Warehouse fields
#   - Calculated totals
#   - Container capacity
#
# Method: GET
# ------------------------------------------------------------------


# ------------------------------------------------------------------
# Swagger Schema: Warehouse Dashboard Response
# ------------------------------------------------------------------

warehouse_dashboard_response_schema = openapi.Schema(
    type=openapi.TYPE_ARRAY,
    items=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={

            "subprogram_id": openapi.Schema(type=openapi.TYPE_INTEGER),

            "program_name": openapi.Schema(type=openapi.TYPE_STRING),
            "customer_name": openapi.Schema(type=openapi.TYPE_STRING),
            "program_type": openapi.Schema(
                type=openapi.TYPE_STRING,
                enum=["TOWEL", "BEDSHEET", "TERRY TOWEL", "BATH ROBE"]
            ),

            "article_no": openapi.Schema(type=openapi.TYPE_STRING),
            "so_item_text": openapi.Schema(type=openapi.TYPE_STRING),
            "possible_ca": openapi.Schema(type=openapi.TYPE_INTEGER),
            "ship_qty": openapi.Schema(type=openapi.TYPE_INTEGER),

            "pieces_per_carton": openapi.Schema(type=openapi.TYPE_NUMBER),
            "height": openapi.Schema(type=openapi.TYPE_NUMBER),
            "width": openapi.Schema(type=openapi.TYPE_NUMBER),
            "length": openapi.Schema(type=openapi.TYPE_NUMBER),

            "cbm_per_carton": openapi.Schema(type=openapi.TYPE_NUMBER),
            "net_wt_per_carton": openapi.Schema(type=openapi.TYPE_NUMBER),
            "gross_wt_per_carton": openapi.Schema(type=openapi.TYPE_NUMBER),

            "total_cbm": openapi.Schema(type=openapi.TYPE_NUMBER),
            "total_net_wt": openapi.Schema(type=openapi.TYPE_NUMBER),
            "total_gross_wt": openapi.Schema(type=openapi.TYPE_NUMBER),

            "cartons_per_20ft": openapi.Schema(type=openapi.TYPE_NUMBER),
            "cartons_per_40ft": openapi.Schema(type=openapi.TYPE_NUMBER),

            "upc": openapi.Schema(type=openapi.TYPE_STRING),
            "final_destination": openapi.Schema(type=openapi.TYPE_STRING),
        }
    )
)


@swagger_auto_schema(
    method="get",
    operation_summary="Warehouse Dashboard Data",
    operation_description="Returns finalized subprogram data for warehouse dashboard",
    responses={
        200: warehouse_dashboard_response_schema,
        401: "Unauthorized"
    }
)
@api_view(["GET"])
@permission_classes([IsAuthenticated])
def warehouse_dashboard(request):

    subprograms = CartonProgramSubProgram.objects.select_related(
        "carton_program"
    ).filter(
        carton_program__activity_statuses__status="Final Working Submitted"
    ).distinct()

    data = []

    for sp in subprograms:

        program = sp.carton_program

        data.append({
            "subprogram_id": sp.id,

            # Program Info
            "program_name": program.program_name,
            "customer_name": program.customer_name,
            "program_type": program.program_type,

            # Warehouse Fields
            "article_no": sp.article_no,
            "so_item_text": sp.so_item_text,
            "possible_ca": sp.possible_ca,
            "ship_qty": sp.ship_qty,

            # Carton Dimensions
            "pieces_per_carton": sp.pieces_per_carton,
            "height": sp.carton_height,
            "width": sp.carton_width,
            "length": sp.carton_length,

            # Calculations
            "cbm_per_carton": sp.cbm_per_carton,
            "net_wt_per_carton": sp.net_wt_per_carton,
            "gross_wt_per_carton": sp.gross_wt_per_carton,

            "total_cbm": sp.total_cbm,
            "total_net_wt": sp.total_net_wt,
            "total_gross_wt": sp.total_gross_wt,

            # Container
            "cartons_per_20ft": sp.cartons_per_container("20FT"),
            "cartons_per_40ft": sp.cartons_per_container("40FT"),

            "upc": sp.upc,
            "final_destination": sp.final_destination,
        })

    return Response(data)




# ------------------------------------------------------------------
# API: Update Warehouse Row
#
# Description:
#   Allows warehouse to update final shipment details.
#
#   Updates:
#   - possible_ca
#   - ship_qty
#   - gross_wt_per_carton
#   - upc
#   - final_destination
#
#   Only allowed for programs with status:
#   "Final Working Submitted"
#
#   Returns recalculated totals and container capacity.
#
# Method: POST
# ------------------------------------------------------------------



# ------------------------------------------------------------------
# Swagger Schema: Warehouse Update
# ------------------------------------------------------------------

warehouse_update_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["subprogram_id"],
    properties={
        "subprogram_id": openapi.Schema(type=openapi.TYPE_INTEGER),
        "possible_ca": openapi.Schema(type=openapi.TYPE_INTEGER),
        "ship_qty": openapi.Schema(type=openapi.TYPE_INTEGER),
        "gross_wt_per_carton": openapi.Schema(type=openapi.TYPE_NUMBER),
        "upc": openapi.Schema(type=openapi.TYPE_STRING),
        "final_destination": openapi.Schema(type=openapi.TYPE_STRING),
    }
)

warehouse_update_response_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "message": openapi.Schema(type=openapi.TYPE_STRING),

        "cbm_per_carton": openapi.Schema(type=openapi.TYPE_NUMBER),
        "net_wt_per_carton": openapi.Schema(type=openapi.TYPE_NUMBER),

        "total_cbm": openapi.Schema(type=openapi.TYPE_NUMBER),
        "total_net_wt": openapi.Schema(type=openapi.TYPE_NUMBER),
        "total_gross_wt": openapi.Schema(type=openapi.TYPE_NUMBER),

        "cartons_per_20ft": openapi.Schema(type=openapi.TYPE_NUMBER),
        "cartons_per_40ft": openapi.Schema(type=openapi.TYPE_NUMBER),
    }
)



@swagger_auto_schema(
    method="post",
    operation_summary="Update Warehouse Row",
    request_body=warehouse_update_schema,
    responses={
        200: warehouse_update_response_schema,
        400: "Bad Request",
        404: "Not Found"
    }
)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def update_warehouse_row(request):

    data = request.data
    subprogram_id = data.get("subprogram_id")

    if not subprogram_id:
        return Response(
            {"error": "subprogram_id is required"},
            status=400
        )

    try:
        sp = CartonProgramSubProgram.objects.select_related(
            "carton_program"
        ).get(id=subprogram_id)
    except CartonProgramSubProgram.DoesNotExist:
        return Response(
            {"error": "Invalid subprogram_id"},
            status=404
        )

    # --------------------------------------------------
    # VALIDATE STATUS
    # --------------------------------------------------

    if not sp.carton_program.activity_statuses.filter(
        status="Final Working Submitted"
    ).exists():
        return Response(
            {"error": "Only finalized programs can be updated"},
            status=400
        )

    # --------------------------------------------------
    # UPDATE FIELDS
    # --------------------------------------------------

    sp.possible_ca = data.get("possible_ca", sp.possible_ca)
    sp.ship_qty = data.get("ship_qty", sp.ship_qty)
    sp.gross_wt_per_carton = data.get("gross_wt_per_carton", sp.gross_wt_per_carton)
    sp.upc = data.get("upc", sp.upc)
    sp.final_destination = data.get("final_destination", sp.final_destination)

    sp.save()

    # --------------------------------------------------
    # LOG
    # --------------------------------------------------

    create_log(
        module_name="Warehouse",
        record_id=sp.id,
        action="Updated",
        message="Warehouse updated shipment details",
        user=request.user
    )

    # --------------------------------------------------
    # RESPONSE
    # --------------------------------------------------

    return Response({
        "message": "Updated Successfully",

        "cbm_per_carton": sp.cbm_per_carton,
        "net_wt_per_carton": sp.net_wt_per_carton,

        "total_cbm": sp.total_cbm,
        "total_net_wt": sp.total_net_wt,
        "total_gross_wt": sp.total_gross_wt,

        "cartons_per_20ft": sp.cartons_per_container("20FT"),
        "cartons_per_40ft": sp.cartons_per_container("40FT"),
    })





# ------------------------------------------------------------------
# Swagger Schema: Gusset Program Specification
# ------------------------------------------------------------------

gusset_program_spec_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "program": openapi.Schema(type=openapi.TYPE_STRING),
        "style": openapi.Schema(type=openapi.TYPE_STRING),

        "width_in": openapi.Schema(type=openapi.TYPE_NUMBER),
        "width_cm": openapi.Schema(type=openapi.TYPE_NUMBER),

        "length_in": openapi.Schema(type=openapi.TYPE_NUMBER),
        "length_cm": openapi.Schema(type=openapi.TYPE_NUMBER),

        "wt_per_unit": openapi.Schema(type=openapi.TYPE_NUMBER),

        "gsm": openapi.Schema(type=openapi.TYPE_NUMBER),

        "unit_per_carton": openapi.Schema(type=openapi.TYPE_INTEGER),

        "inner_pack_unit_qty": openapi.Schema(type=openapi.TYPE_STRING),

        "fold": openapi.Schema(type=openapi.TYPE_STRING),
    }
)


# ------------------------------------------------------------------
# Swagger Schema: Gusset Sample Program
# ------------------------------------------------------------------

gusset_sample_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "program_name": openapi.Schema(type=openapi.TYPE_STRING),
        "size": openapi.Schema(type=openapi.TYPE_STRING),
        "sample": openapi.Schema(type=openapi.TYPE_STRING),
        "quality": openapi.Schema(type=openapi.TYPE_STRING),

        "lbs_per_dz": openapi.Schema(type=openapi.TYPE_NUMBER),

        "gsm": openapi.Schema(type=openapi.TYPE_NUMBER),

        "shade": openapi.Schema(type=openapi.TYPE_STRING),

        "width_in": openapi.Schema(type=openapi.TYPE_NUMBER),
        "length_in": openapi.Schema(type=openapi.TYPE_NUMBER),

        "width_cm": openapi.Schema(type=openapi.TYPE_NUMBER),
        "length_cm": openapi.Schema(type=openapi.TYPE_NUMBER),
    }
)


# ------------------------------------------------------------------
# Swagger Schema: Submit Gusset Program
# ------------------------------------------------------------------

submit_gusset_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["customer_name", "program_name"],
    properties={

        "customer_name": openapi.Schema(type=openapi.TYPE_STRING),

        "program_name": openapi.Schema(type=openapi.TYPE_STRING),

        "tc": openapi.Schema(type=openapi.TYPE_STRING),
        "weave": openapi.Schema(type=openapi.TYPE_STRING),
        "product_group": openapi.Schema(type=openapi.TYPE_STRING),

        "size": openapi.Schema(type=openapi.TYPE_STRING),

        "down": openapi.Schema(type=openapi.TYPE_STRING),

        "value_addition_flat_sheet": openapi.Schema(type=openapi.TYPE_STRING),
        "value_addition_duvet_cover": openapi.Schema(type=openapi.TYPE_STRING),
        "value_addition_fitted_sheet": openapi.Schema(type=openapi.TYPE_STRING),
        "value_addition_pillowcase": openapi.Schema(type=openapi.TYPE_STRING),

        "fold_size_inches": openapi.Schema(type=openapi.TYPE_STRING),

        "cardboard_required": openapi.Schema(type=openapi.TYPE_BOOLEAN),

        "fold_type": openapi.Schema(type=openapi.TYPE_STRING),

        "ply": openapi.Schema(type=openapi.TYPE_STRING),

        "fold_on_side": openapi.Schema(type=openapi.TYPE_STRING),

        "reference_program": openapi.Schema(type=openapi.TYPE_STRING),

        "comments": openapi.Schema(type=openapi.TYPE_STRING),

        "polybag_required": openapi.Schema(type=openapi.TYPE_BOOLEAN),

        "material_type": openapi.Schema(type=openapi.TYPE_STRING),

        "opening_type": openapi.Schema(type=openapi.TYPE_STRING),

        "opening_on_side": openapi.Schema(type=openapi.TYPE_STRING),

        "inlay_or_belly_band": openapi.Schema(type=openapi.TYPE_STRING),

        "polybag_type": openapi.Schema(type=openapi.TYPE_STRING),

        "program_specifications": openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=gusset_program_spec_schema
        ),

        "samples": openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=gusset_sample_schema
        )
    }
)


# ------------------------------------------------------------------
# API: Submit Gusset Program
#
# Description:
#   Creates a new Gusset program with:
#   - Product details
#   - Cardboard stiffener details
#   - Polybag details
#   - Program specifications
#   - Sample programs
#
# Method: POST
# ------------------------------------------------------------------


@swagger_auto_schema(
    method="post",
    operation_summary="Submit Gusset Program",
    request_body=submit_gusset_schema,
    responses={
        201: "Program Created",
        400: "Bad Request"
    }
)

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def submit_gusset_program(request):

    data = request.data

    specs = data.get("program_specifications", [])
    samples = data.get("samples", [])

    gusset = GussetProgram.objects.create(

        customer_name=data.get("customer_name"),
        program_name=data.get("program_name"),

        tc=data.get("tc"),
        weave=data.get("weave"),
        product_group=data.get("product_group"),
        size=data.get("size"),
        down=data.get("down"),

        value_addition_flat_sheet=data.get("value_addition_flat_sheet"),
        value_addition_duvet_cover=data.get("value_addition_duvet_cover"),
        value_addition_fitted_sheet=data.get("value_addition_fitted_sheet"),
        value_addition_pillowcase=data.get("value_addition_pillowcase"),

        fold_size_inches=data.get("fold_size_inches"),

        cardboard_required=data.get("cardboard_required"),
        fold_type=data.get("fold_type"),
        ply=data.get("ply"),
        fold_on_side=data.get("fold_on_side"),

        reference_program=data.get("reference_program"),
        comments=data.get("comments"),

        polybag_required=data.get("polybag_required"),
        material_type=data.get("material_type"),
        opening_type=data.get("opening_type"),
        opening_on_side=data.get("opening_on_side"),
        inlay_or_belly_band=data.get("inlay_or_belly_band"),
        polybag_type=data.get("polybag_type"),

        created_by=request.user
    )

    # Program Specs

    for sp in specs:

        GussetProgramSpecification.objects.create(
            gusset_program=gusset,
            program=sp.get("program"),
            style=sp.get("style"),
            width_in=sp.get("width_in"),
            width_cm=sp.get("width_cm"),
            length_in=sp.get("length_in"),
            length_cm=sp.get("length_cm"),
            wt_per_unit=sp.get("wt_per_unit"),
            gsm=sp.get("gsm"),
            unit_per_carton=sp.get("unit_per_carton"),
            inner_pack_unit_qty=sp.get("inner_pack_unit_qty"),
            fold=sp.get("fold"),
        )

    # Sample Programs

    for sm in samples:

        GussetSampleProgram.objects.create(
            gusset_program=gusset,
            program_name=sm.get("program_name"),
            size=sm.get("size"),
            sample=sm.get("sample"),
            quality=sm.get("quality"),
            lbs_per_dz=sm.get("lbs_per_dz"),
            gsm=sm.get("gsm"),
            shade=sm.get("shade"),
            width_in=sm.get("width_in"),
            length_in=sm.get("length_in"),
            width_cm=sm.get("width_cm"),
            length_cm=sm.get("length_cm"),
        )

    return Response({
        "message": "Gusset Program Created",
        "program_id": gusset.id
    })
    



# ------------------------------------------------------------------
# Swagger Schema: Gusset List Response
# ------------------------------------------------------------------

gusset_list_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={

        "program_id": openapi.Schema(type=openapi.TYPE_INTEGER),

        "customer_name": openapi.Schema(type=openapi.TYPE_STRING),

        "program_name": openapi.Schema(type=openapi.TYPE_STRING),

        "created_on": openapi.Schema(type=openapi.TYPE_STRING),
    }
)


# ------------------------------------------------------------------
# API: List Gusset Programs
#
# Description:
#   Returns all Gusset programs for dashboard listing.
#
# Method: GET
# ------------------------------------------------------------------


@swagger_auto_schema(
    method="get",
    operation_summary="List Gusset Programs",
    responses={
        200: openapi.Schema(
            type=openapi.TYPE_ARRAY,
            items=gusset_list_schema
        )
    }
)

    
@api_view(["GET"])
@permission_classes([IsAuthenticated])
def list_gusset_program(request):

    records = GussetProgram.objects.all()

    data = []

    for r in records:

        data.append({
            "program_id": r.id,
            "customer_name": r.customer_name,
            "program_name": r.program_name,
            "created_on": r.created_on.strftime("%d-%m-%Y"),
            "expected_date_program": r.expected_date_confirmation
        })

    return Response(data)




# ------------------------------------------------------------------
# Swagger Schema: Gusset Details Request
# ------------------------------------------------------------------

gusset_details_request_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["program_id"],
    properties={
        "program_id": openapi.Schema(
            type=openapi.TYPE_INTEGER
        )
    }
)


# ------------------------------------------------------------------
# API: Get Gusset Program Details
#
# Description:
#   Returns complete Gusset program including:
#   - Product section
#   - Cardboard stiffener section
#   - Polybag section
#   - Program specifications
#   - Sample programs
#
# Used when user clicks "View" on the list page.
#
# Method: POST
# ------------------------------------------------------------------


@swagger_auto_schema(
    method="post",
    operation_summary="Get Gusset Program Details",
    request_body=gusset_details_request_schema,
)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def get_gusset_program_details(request):

    program_id = request.data.get("program_id")

    gusset = GussetProgram.objects.get(id=program_id)

    specs = []
    samples = []

    for s in gusset.program_specifications.all():

        specs.append({
            "program": s.program,
            "style": s.style,
            "width_in": s.width_in,
            "width_cm": s.width_cm,
            "length_in": s.length_in,
            "length_cm": s.length_cm,
            "wt_per_unit": s.wt_per_unit,
            "gsm": s.gsm,
            "unit_per_carton": s.unit_per_carton,
            "inner_pack_unit_qty": s.inner_pack_unit_qty,
            "fold": s.fold,
            

        })

    for sm in gusset.samples.all():

        samples.append({
            "program_name": sm.program_name,
            "size": sm.size,
            "sample": sm.sample,
            "quality": sm.quality,
            "gsm": sm.gsm,
            "shade": sm.shade
        })

    return Response({

        "program_id": gusset.id,

        "customer_name": gusset.customer_name,
        "program_name": gusset.program_name,

        "tc": gusset.tc,
        "weave": gusset.weave,
        "product_group": gusset.product_group,
        "size": gusset.size,
        "expected_date_program": gusset.expected_date_confirmation,

        "program_specifications": specs,

        "samples": samples
    })
    



# ------------------------------------------------------------------
# Swagger Schema: Edit Gusset Program
# ------------------------------------------------------------------

gusset_edit_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["program_id"],
    properties={

        "program_id": openapi.Schema(
            type=openapi.TYPE_INTEGER,
            description="Gusset Program ID"
        ),

        "expected_date_confirmation": openapi.Schema(
            type=openapi.TYPE_STRING,
            format="date",
            description="Expected date confirmation"
        )
    }
)

gusset_edit_response_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    properties={
        "message": openapi.Schema(type=openapi.TYPE_STRING)
    }
)

# ------------------------------------------------------------------
# API: Edit Gusset Program
#
# Description:
#   Updates specific fields of Gusset Program.
#
#   Currently supports:
#   - expected_date_confirmation
#
# Method: POST
# ------------------------------------------------------------------

@swagger_auto_schema(
    method="post",
    operation_summary="Edit Gusset Program",
    request_body=gusset_edit_schema,
    responses={
        200: gusset_edit_response_schema,
        400: "Bad Request",
        404: "Not Found"
    }
)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def edit_gusset_program(request):

    data = request.data
    program_id = data.get("program_id")

    if not program_id:
        return Response(
            {"error": "program_id is required"},
            status=400
        )

    try:
        sp = GussetProgram.objects.get(id=program_id)
    except GussetProgram.DoesNotExist:
        return Response(
            {"error": "Invalid program_id"},
            status=404
        )

    sp.expected_date_confirmation = data.get(
        "expected_date_confirmation",
        sp.expected_date_confirmation
    )

    sp.save()

    create_log(
        module_name="GussetProgram",
        record_id=sp.id,
        action="Updated",
        message="Gusset Program Expected Date Updated",
        user=request.user
    )

    return Response(
        {"message": "Gusset Expected Date Updated Successfully"},
        status=200
    )
    
    
# ------------------------------------------------------------------
# Swagger Schema: Accept Gusset Program
# ------------------------------------------------------------------

gusset_accept_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["program_id"],
    properties={
        "program_id": openapi.Schema(
            type=openapi.TYPE_INTEGER,
            description="Gusset Program ID"
        )
    }
)


# ------------------------------------------------------------------
# API: Accept Gusset Program
#
# Description:
#   Marks the Gusset Program as Accepted.
#
# Method: POST
# ------------------------------------------------------------------

@swagger_auto_schema(
    method="post",
    operation_summary="Accept Gusset Program",
    request_body=gusset_accept_schema,
    responses={
        200: "Accepted Successfully",
        400: "Bad Request",
        404: "Not Found"
    }
)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def accept_gusset_program(request):

    program_id = request.data.get("program_id")

    if not program_id:
        return Response(
            {"error": "program_id is required"},
            status=400
        )

    try:
        sp = GussetProgram.objects.get(id=program_id)
    except GussetProgram.DoesNotExist:
        return Response(
            {"error": "Invalid program_id"},
            status=404
        )

    sp.status = "Accepted"
    sp.rejection_reason = None
    sp.save()

    create_log(
        module_name="GussetProgram",
        record_id=sp.id,
        action="Accepted",
        message="Gusset Program Accepted",
        user=request.user
    )

    return Response(
        {"message": "Gusset Program Accepted Successfully"},
        status=200
    )
    
    
# ------------------------------------------------------------------
# Swagger Schema: Reject Gusset Program
# ------------------------------------------------------------------

gusset_reject_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=["program_id", "rejection_reason"],
    properties={
        "program_id": openapi.Schema(
            type=openapi.TYPE_INTEGER
        ),
        "rejection_reason": openapi.Schema(
            type=openapi.TYPE_STRING,
            description="Reason for rejection"
        )
    }
)


# ------------------------------------------------------------------
# API: Reject Gusset Program
#
# Description:
#   Rejects the Gusset Program with a reason.
#
# Method: POST
# ------------------------------------------------------------------

@swagger_auto_schema(
    method="post",
    operation_summary="Reject Gusset Program",
    request_body=gusset_reject_schema,
    responses={
        200: "Rejected Successfully",
        400: "Bad Request",
        404: "Not Found"
    }
)
@api_view(["POST"])
@permission_classes([IsAuthenticated])
def reject_gusset_program(request):

    program_id = request.data.get("program_id")
    rejection_reason = request.data.get("rejection_reason")

    if not program_id:
        return Response(
            {"error": "program_id is required"},
            status=400
        )

    if not rejection_reason:
        return Response(
            {"error": "rejection_reason is required"},
            status=400
        )

    try:
        sp = GussetProgram.objects.get(id=program_id)
    except GussetProgram.DoesNotExist:
        return Response(
            {"error": "Invalid program_id"},
            status=404
        )

    sp.status = "Rejected"
    sp.rejection_reason = rejection_reason
    sp.save()

    create_log(
        module_name="GussetProgram",
        record_id=sp.id,
        action="Rejected",
        message=f"Gusset Program Rejected: {rejection_reason}",
        user=request.user
    )

    return Response(
        {"message": "Gusset Program Rejected Successfully"},
        status=200
    )



from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema

# Request Schema
carton_calc_ai_request_schema = openapi.Schema(
    type=openapi.TYPE_OBJECT,
    required=['program_id'],
    properties={
        'program_id': openapi.Schema(
            type=openapi.TYPE_INTEGER,
            description='ID of the carton program',
            example=1
        )
    }
)

# Response Schema
carton_calc_ai_response_schema = openapi.Response(
    description='Carton calculation results',
    schema=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'program_id': openapi.Schema(
                type=openapi.TYPE_INTEGER,
                description='Program ID',
                example=1
            ),
            'program_name': openapi.Schema(
                type=openapi.TYPE_STRING,
                description='Name of the program',
                example='Summer Collection 2024'
            ),
            'results': openapi.Schema(
                type=openapi.TYPE_ARRAY,
                items=openapi.Schema(
                    type=openapi.TYPE_OBJECT,
                    properties={
                        'subprogram_id': openapi.Schema(
                            type=openapi.TYPE_INTEGER,
                            description='Subprogram ID',
                            example=101
                        ),
                        'program_name': openapi.Schema(
                            type=openapi.TYPE_STRING,
                            description='Subprogram name',
                            example='T-Shirt Basic'
                        ),
                        'fold': openapi.Schema(
                            type=openapi.TYPE_STRING,
                            description='Folding type',
                            example='Standard',
                            nullable=True
                        ),
                        'folded_length': openapi.Schema(
                            type=openapi.TYPE_NUMBER,
                            format=openapi.FORMAT_FLOAT,
                            description='Folded length in cm',
                            example=25.5,
                            nullable=True
                        ),
                        'folded_width': openapi.Schema(
                            type=openapi.TYPE_NUMBER,
                            format=openapi.FORMAT_FLOAT,
                            description='Folded width in cm',
                            example=20.0,
                            nullable=True
                        ),
                        'carton': openapi.Schema(
                            type=openapi.TYPE_OBJECT,
                            properties={
                                'length': openapi.Schema(
                                    type=openapi.TYPE_NUMBER,
                                    format=openapi.FORMAT_FLOAT,
                                    description='Carton length in cm',
                                    example=60.0,
                                    nullable=True
                                ),
                                'width': openapi.Schema(
                                    type=openapi.TYPE_NUMBER,
                                    format=openapi.FORMAT_FLOAT,
                                    description='Carton width in cm',
                                    example=40.0,
                                    nullable=True
                                ),
                                'height': openapi.Schema(
                                    type=openapi.TYPE_NUMBER,
                                    format=openapi.FORMAT_FLOAT,
                                    description='Carton height in cm',
                                    example=35.0,
                                    nullable=True
                                ),
                                'cbm': openapi.Schema(
                                    type=openapi.TYPE_NUMBER,
                                    format=openapi.FORMAT_FLOAT,
                                    description='Cubic meters per carton',
                                    example=0.084,
                                    nullable=True
                                )
                            }
                        ),
                        'container': openapi.Schema(
                            type=openapi.TYPE_OBJECT,
                            properties={
                                '20FT': openapi.Schema(
                                    type=openapi.TYPE_INTEGER,
                                    description='Number of cartons in 20FT container',
                                    example=320,
                                    nullable=True
                                ),
                                '40FT': openapi.Schema(
                                    type=openapi.TYPE_INTEGER,
                                    description='Number of cartons in 40FT container',
                                    example=680,
                                    nullable=True
                                ),
                                '40HC': openapi.Schema(
                                    type=openapi.TYPE_INTEGER,
                                    description='Number of cartons in 40HC container',
                                    example=800,
                                    nullable=True
                                )
                            }
                        )
                    }
                )
            )
        }
    ),
    examples={
        'application/json': {
            'program_id': 1,
            'program_name': 'Summer Collection 2024',
            'results': [
                {
                    'subprogram_id': 101,
                    'program_name': 'T-Shirt Basic',
                    'fold': 'Standard',
                    'folded_length': 25.5,
                    'folded_width': 20.0,
                    'carton': {
                        'length': 60.0,
                        'width': 40.0,
                        'height': 35.0,
                        'cbm': 0.084
                    },
                    'container': {
                        '20FT': 320,
                        '40FT': 680,
                        '40HC': 800
                    }
                }
            ]
        }
    }
)

# Error response schemas
error_400_schema = openapi.Response(
    description='Bad Request - Missing program_id',
    schema=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'error': openapi.Schema(
                type=openapi.TYPE_STRING,
                example='program_id is required'
            )
        }
    )
)

error_404_schema = openapi.Response(
    description='Not Found - Program does not exist',
    schema=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'error': openapi.Schema(
                type=openapi.TYPE_STRING,
                example='Program not found'
            )
        }
    )
)

# Apply to your view
@swagger_auto_schema(
    method='post',
    operation_summary="Get Carton Calculations (AI)",
    operation_description="Retrieve carton calculation details for all subprograms under a specific program",
    request_body=carton_calc_ai_request_schema,
    responses={
        200: carton_calc_ai_response_schema,
        400: error_400_schema,
        404: error_404_schema
    },
    tags=['Carton Calculations']
)

@api_view(["POST"])   # 👈 IMPORTANT: POST, not GET
# NOTE: this endpoint is now ALSO the "Recalculate" button action - it marks
# every subprogram in the program as recalculated (is_recalculated=True),
# which unlocks Tentative/Final submit in bulk_update_tqm_subprogram.
# Frontend should call this whenever the TQM user clicks "Recalculate" and
# keep Tentative/Final submit disabled until is_recalculated is true for
# every subprogram in the response below.
@permission_classes([IsAuthenticated])
def get_carton_calculations_ai(request):

    program_id = request.data.get("program_id")

    if not program_id:
        return Response(
            {"error": "program_id is required"},
            status=status.HTTP_400_BAD_REQUEST
        )

    try:
        program = CartonProgram.objects.get(id=program_id)
    except CartonProgram.DoesNotExist:
        return Response(
            {"error": "Program not found"},
            status=status.HTTP_404_NOT_FOUND
        )

    subprograms = program.subprograms.all()

    # This endpoint IS the "Recalculate" action - mark every subprogram as
    # recalculated as of now, using whatever carton dims are currently saved.
    now = timezone.now()
    subprograms.update(is_recalculated=True, last_recalculated_on=now)

    data = []

    for sp in subprograms:
        data.append({
            "subprogram_id": sp.id,
            "program_name": sp.program_name,

            "fold": sp.fold,
            "folded_length": sp.folded_length,
            "folded_width": sp.folded_width,

            "carton": {
                "length": sp.carton_length,
                "width": sp.carton_width,
                "height": sp.carton_height,
                "cbm": sp.calculated_cbm_per_carton
            },

            "container": {
                "20FT": sp.cartons_per_container("20FT"),
                "40FT": sp.cartons_per_container("40FT"),
                "40HC": sp.cartons_per_container("40HC"),
            },

            "is_recalculated": True,
            "last_recalculated_on": now.strftime("%d-%m-%Y %H:%M:%S"),
        })

    return Response({
        "program_id": program.id,
        "program_name": program.program_name,
        "results": data
    }, status=status.HTTP_200_OK)