import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../../api/axiosInstance';
import { ArrowLeft, Paperclip, Eye } from 'lucide-react';
import Table from '../Form/Table';
import { toast } from 'react-toastify';

function GussetView() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [details, setDetails] = useState(null);
  const [subprograms, setSubprograms] = useState([]);
  const [samples, setSamples] = useState([]);
  const [attachments, setAttachments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [checkingLink, setCheckingLink] = useState(null);
  const [showErrorPopup, setShowErrorPopup] = useState(false);

  // ==================== FETCH GUSSET DETAILS ====================
  useEffect(() => {
    const fetchDetails = async () => {
      try {
        setLoading(true);
        const response = await api.post(
          `/api/details/`,
          { program_id: id }
        );
        const data = response.data;

        setDetails(data);
        setSubprograms(data.program_specifications || []);
        setSamples(data.samples || []);
        setAttachments(data.attachments || []);
        setError(null);
      } catch (err) {
        console.error(err);
        setError('Failed to load details.');
      } finally {
        setLoading(false);
      }
    };

    if (id) fetchDetails();
  }, [id]);

  // ==================== ATTACHMENT HANDLER ====================
  const handleAttachmentClick = async (attachment, index) => {
    const fileUrl = attachment.file_url;
    const attachmentId = attachment.id || index;
    if (!fileUrl) return;

    setCheckingLink(attachmentId);
    try {
      const response = await fetch(fileUrl, { method: 'HEAD' });
      if (response.ok) {
        window.open(fileUrl, '_blank', 'noopener,noreferrer');
      } else {
        setShowErrorPopup(true);
      }
    } catch (err) {
      setShowErrorPopup(true);
    } finally {
      setCheckingLink(null);
    }
  };

  // ==================== DYNAMIC LABEL (TC / GSM) ====================
  const gsmLabel = details?.tc ? 'TC' : 'GSM';

  if (loading) {
    return (
      <div className="p-8 flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#003366]"></div>
      </div>
    );
  }

  if (error || !details) {
    return (
      <div className="p-8 text-center">
        <p className="text-red-600 mb-4">{error || 'Not found'}</p>
        <button onClick={() => navigate(-1)} className="cursor-pointer px-4 py-2 bg-[#003366] text-white rounded hover:bg-[#002244] transition-colors">
          Go Back
        </button>
      </div>
    );
  }

  return (
    <>
      <div className="h-full flex flex-col max-w-7xl mx-auto">
        {/* Header */}
        <div className="sticky top-0 z-20 bg-gray-50 p-4 md:p-6 lg:p-8 border-b">
          <div className="flex items-center gap-3 mb-2">
            <button onClick={() => navigate(-1)} className="cursor-pointer hover:bg-gray-100 p-2 rounded transition-colors">
              <ArrowLeft size={20} />
            </button>
            <h1 className="text-2xl font-bold">Gusset Program – {details.program_name}</h1>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
          {/* Program Information */}
          <div className="bg-white shadow-sm rounded-lg border mb-8">
            <div className="p-5 border-b">
              <h2 className="text-lg font-semibold">Gusset Program Information</h2>
            </div>
            <div className="p-5">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div>
                  <p className="text-sm text-gray-500">Customer Name</p>
                  <p className="font-medium">{details.customer_name || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Program Name</p>
                  <p className="font-medium">{details.program_name || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">TC</p>
                  <p className="font-medium">{details.tc || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Weave</p>
                  <p className="font-medium">{details.weave || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Product Group</p>
                  <p className="font-medium">{details.product_group || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Size</p>
                  <p className="font-medium">{details.size || '-'}</p>
                </div>
              </div>

              {/* Attachments */}
              <div className="mt-8 pt-6 border-t border-gray-200">
                <h3 className="text-sm font-medium text-gray-700 mb-3">Attachments</h3>
                {(!attachments || attachments.length === 0) ? (
                  <p className="text-sm text-gray-400 italic">No attachments available</p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {attachments.map((attachment, index) => {
                      const attachmentId = attachment.id || index;
                      const isChecking = checkingLink === attachmentId;
                      const noUrl = !attachment.file_url;

                      return (
                        <button
                          key={attachmentId}
                          disabled={isChecking || noUrl}
                          onClick={() => handleAttachmentClick(attachment, index)}
                          className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all cursor-pointer border ${
                            noUrl
                              ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed'
                              : 'bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-100'
                          }`}
                        >
                          {isChecking ? (
                            <div className="animate-spin h-3 w-3 border-2 border-blue-700 border-t-transparent rounded-full" />
                          ) : (
                            <Paperclip size={14} />
                          )}
                          <span className="text-sm font-medium">
                            {noUrl ? "No Link" : `View Attachment ${attachments.length > 1 ? index + 1 : ''}`}
                          </span>
                          {!noUrl && <Eye size={14} />}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Program Specifications Table */}
          {subprograms && subprograms.length > 0 && (
            <div className="bg-white shadow-sm rounded-lg border mb-8">
              <div className="p-3 border-b">
                <h2 className="text-lg font-semibold">Program Specifications</h2>
              </div>
              <div className="p-2 overflow-x-auto">
                <Table
                  title="Program Specifications"
                  headers={[
                    { label: "Program", key: "program" },
                    { label: "Style", key: "style" },
                    { label: "W-In", key: "width_in" },
                    { label: "W-Cm", key: "width_cm" },
                    { label: "L-In", key: "length_in" },
                    { label: "L-Cm", key: "length_cm" },
                    { label: "Wt/Unit", key: "wt_per_unit" },
                    { label: gsmLabel, key: "gsm" },
                    { label: "Unit/Carton", key: "unit_per_carton" },
                    { label: "Inner Pack Unit Quantity", key: "inner_pack_unit_qty" },
                    { label: "Fold", key: "fold" },
                  ]}
                  data={subprograms}
                  type="flat"
                  readOnly={true}
                />
              </div>
            </div>
          )}

          {/* Samples Table */}
          {samples && samples.length > 0 && (
            <div className="bg-white shadow-sm rounded-lg border mb-8">
              <div className="p-2 overflow-x-auto">
                <Table
                  title="Sample Specifications"
                  headers={[
                    { label: "Program", key: "program_name" },
                    { label: "Sample", key: "sample" },
                    { label: "Size", key: "size" },
                    { label: "Quality", key: "quality" },
                    { label: gsmLabel, key: "gsm" },
                    { label: "Shade", key: "shade" },
                    { label: "Lbs/Dz", key: "lbs_per_dz" },
                    { label: "Width (In)", key: "width_in" },
                    { label: "Width (Cm)", key: "width_cm" },
                    { label: "Length (In)", key: "length_in" },
                    { label: "Length (Cm)", key: "length_cm" },
                  ]}
                  data={samples}
                  type="flat"
                  readOnly={true}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Error Popup */}
      {showErrorPopup && (
        <div className="fixed inset-0 h-[129vh] bg-black/50 flex items-center justify-center z-[9999] p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full p-6 text-center">
            <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-3xl font-bold">!</span>
            </div>
            <h2 className="text-xl font-bold text-gray-800 mb-2">Something went wrong</h2>
            <p className="text-gray-600 mb-6">The attachment link is currently broken or the file is missing (404 Error).</p>
            <button onClick={() => setShowErrorPopup(false)} className="w-full cursor-pointer py-2 bg-gray-800 hover:bg-gray-900 text-white rounded-lg font-medium transition-colors">
              Close Notification
            </button>
          </div>
        </div>
      )}
    </>
  );
}

export default GussetView;